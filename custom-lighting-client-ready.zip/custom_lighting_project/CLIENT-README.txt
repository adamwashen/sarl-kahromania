CUSTOM LIGHTING E-COMMERCE — CLIENT VERSION

IMPORTANT:
This is a web application project (Next.js), not a simple index.html file.
Do NOT open the src folder or try to open an HTML file directly.

TO VIEW THE SITE:
The easiest method is to use the online website link provided by the developer.

FOR THE DEVELOPER / HOSTING:
1. Upload this project to a compatible hosting service.
2. Install dependencies.
3. Run the production build.
4. Deploy the generated application.
5. Send the client the final HTTPS website link.

The client only needs the website link to use the site in Chrome/Safari.
