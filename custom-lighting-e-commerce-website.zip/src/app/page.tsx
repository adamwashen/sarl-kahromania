import Storefront from "@/components/store/Storefront";

export const dynamic = "force-dynamic";

export default function Home() {
  return <Storefront />;
}
