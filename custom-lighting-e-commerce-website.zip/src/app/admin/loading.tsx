import { Loader2 } from "lucide-react";

export default function AdminLoading() {
  return (
    <div className="grid min-h-screen place-items-center bg-night-950">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="size-10 animate-spin text-ember-500" />
        <p className="text-xs font-bold text-zinc-600">جارٍ فتح لوحة التحكم…</p>
      </div>
    </div>
  );
}
