import { NextRequest } from "next/server";
import { db } from "@/db";
import { products, type NewProduct } from "@/db/schema";
import { asc } from "drizzle-orm";
import { SEED_PRODUCTS } from "@/lib/defaults";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

async function listProducts() {
  return db
    .select()
    .from(products)
    .orderBy(asc(products.sort), asc(products.id));
}

export async function GET() {
  try {
    let rows = await listProducts();
    if (rows.length === 0) {
      await db.insert(products).values(SEED_PRODUCTS).onConflictDoNothing();
      rows = await listProducts();
    }
    return Response.json({ products: rows });
  } catch {
    return Response.json({ products: [] }, { status: 200 });
  }
}

export async function POST(req: NextRequest) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const b = await req.json();
    if (!b?.name?.trim()) {
      return Response.json({ error: "اسم المنتج مطلوب" }, { status: 400 });
    }
    const payload: NewProduct = {
      name: String(b.name).trim(),
      description: String(b.description ?? ""),
      price: Math.max(0, Math.round(Number(b.price) || 0)),
      oldPrice:
        b.oldPrice === null || b.oldPrice === "" || b.oldPrice === undefined
          ? null
          : Math.max(0, Math.round(Number(b.oldPrice) || 0)),
      image: String(b.image ?? ""),
      category: String(b.category ?? "معلّقات"),
      badge: b.badge ? String(b.badge) : null,
      featured: Boolean(b.featured),
      inStock: b.inStock === undefined ? true : Boolean(b.inStock),
      sort: Math.round(Number(b.sort) || 0),
    };
    const [row] = await db.insert(products).values(payload).returning();
    return Response.json({ product: row });
  } catch {
    return Response.json({ error: "تعذّر إضافة المنتج" }, { status: 500 });
  }
}
