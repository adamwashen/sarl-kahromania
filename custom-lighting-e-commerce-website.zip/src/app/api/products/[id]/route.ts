import { NextRequest } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const { id } = await ctx.params;
    const pid = Number(id);
    if (!Number.isFinite(pid)) {
      return Response.json({ error: "معرّف غير صالح" }, { status: 400 });
    }
    const b = await req.json();
    const patch: Record<string, unknown> = {};
    if (b.name !== undefined) patch.name = String(b.name).trim();
    if (b.description !== undefined)
      patch.description = String(b.description ?? "");
    if (b.price !== undefined)
      patch.price = Math.max(0, Math.round(Number(b.price) || 0));
    if (b.oldPrice !== undefined)
      patch.oldPrice =
        b.oldPrice === null || b.oldPrice === ""
          ? null
          : Math.max(0, Math.round(Number(b.oldPrice) || 0));
    if (b.image !== undefined) patch.image = String(b.image ?? "");
    if (b.category !== undefined) patch.category = String(b.category ?? "");
    if (b.badge !== undefined) patch.badge = b.badge ? String(b.badge) : null;
    if (b.featured !== undefined) patch.featured = Boolean(b.featured);
    if (b.inStock !== undefined) patch.inStock = Boolean(b.inStock);
    if (b.sort !== undefined) patch.sort = Math.round(Number(b.sort) || 0);

    const [row] = await db
      .update(products)
      .set(patch)
      .where(eq(products.id, pid))
      .returning();
    if (!row) return Response.json({ error: "المنتج غير موجود" }, { status: 404 });
    return Response.json({ product: row });
  } catch {
    return Response.json({ error: "تعذّر تعديل المنتج" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const { id } = await ctx.params;
    const pid = Number(id);
    await db.delete(products).where(eq(products.id, pid));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "تعذّر حذف المنتج" }, { status: 500 });
  }
}
