import { NextRequest } from "next/server";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

const EXT: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/gif": "gif",
  "image/avif": "avif",
};

export async function POST(req: NextRequest) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const fd = await req.formData();
    const file = fd.get("file");
    if (!(file instanceof File)) {
      return Response.json({ error: "لم يتم إرفاق ملف" }, { status: 400 });
    }
    const ext = EXT[file.type];
    if (!ext) {
      return Response.json(
        { error: "صيغة غير مدعومة (jpg, png, webp, gif, avif)" },
        { status: 400 }
      );
    }
    if (file.size > 6 * 1024 * 1024) {
      return Response.json({ error: "الصورة أكبر من 6MB" }, { status: 400 });
    }
    const buf = Buffer.from(await file.arrayBuffer());
    const dir = path.join(process.cwd(), "public", "uploads");
    await mkdir(dir, { recursive: true });
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    await writeFile(path.join(dir, name), buf);
    return Response.json({ url: `/uploads/${name}` });
  } catch {
    return Response.json({ error: "تعذّر رفع الصورة" }, { status: 500 });
  }
}
