import { NextRequest } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const STATUSES = ["new", "confirmed", "delivered", "cancelled"];

export async function PUT(req: NextRequest, ctx: Ctx) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const { id } = await ctx.params;
    const oid = Number(id);
    const b = await req.json();
    const status = STATUSES.includes(b?.status) ? b.status : "new";
    const [row] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, oid))
      .returning();
    return Response.json({ order: row });
  } catch {
    return Response.json({ error: "تعذّر تحديث الطلب" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const { id } = await ctx.params;
    await db.delete(orders).where(eq(orders.id, Number(id)));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "تعذّر حذف الطلب" }, { status: 500 });
  }
}
