import { NextRequest } from "next/server";
import { db } from "@/db";
import { orders, type OrderItem } from "@/db/schema";
import { desc } from "drizzle-orm";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
    return Response.json({ orders: rows });
  } catch {
    return Response.json({ orders: [] });
  }
}

export async function POST(req: NextRequest) {
  try {
    const b = await req.json();
    const items: OrderItem[] = Array.isArray(b?.items)
      ? b.items
          .map((it: Partial<OrderItem>) => ({
            id: Number(it.id) || 0,
            name: String(it.name ?? "").slice(0, 200),
            price: Math.max(0, Math.round(Number(it.price) || 0)),
            qty: Math.min(99, Math.max(1, Math.round(Number(it.qty) || 1))),
            image: typeof it.image === "string" ? it.image : undefined,
          }))
          .filter((it: OrderItem) => it.name)
      : [];
    if (items.length === 0) {
      return Response.json({ error: "السلة فارغة" }, { status: 400 });
    }
    const total = items.reduce((s, it) => s + it.price * it.qty, 0);
    const [row] = await db
      .insert(orders)
      .values({
        customerName: String(b?.customerName ?? "").slice(0, 120),
        phone: String(b?.phone ?? "").slice(0, 40),
        wilaya: String(b?.wilaya ?? "").slice(0, 80),
        address: String(b?.address ?? "").slice(0, 300),
        notes: String(b?.notes ?? "").slice(0, 500),
        items,
        total,
        status: "new",
      })
      .returning();
    return Response.json({ order: row });
  } catch {
    return Response.json({ error: "تعذّر تسجيل الطلب" }, { status: 500 });
  }
}
