import { NextRequest } from "next/server";
import { db } from "@/db";
import { wholesaleOffers, type NewWholesaleOffer } from "@/db/schema";
import { asc } from "drizzle-orm";
import { SEED_WHOLESALE } from "@/lib/defaults";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

async function listOffers() {
  return db
    .select()
    .from(wholesaleOffers)
    .orderBy(asc(wholesaleOffers.sort), asc(wholesaleOffers.id));
}

export async function GET() {
  try {
    let rows = await listOffers();
    if (rows.length === 0) {
      await db
        .insert(wholesaleOffers)
        .values(SEED_WHOLESALE)
        .onConflictDoNothing();
      rows = await listOffers();
    }
    return Response.json({ offers: rows });
  } catch {
    return Response.json({ offers: [] }, { status: 200 });
  }
}

export async function POST(req: NextRequest) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const b = await req.json();
    if (!b?.name?.trim()) {
      return Response.json({ error: "اسم العرض مطلوب" }, { status: 400 });
    }
    const payload: NewWholesaleOffer = {
      name: String(b.name).trim(),
      description: String(b.description ?? ""),
      minQty: Math.max(1, Math.round(Number(b.minQty) || 1)),
      unitPrice: Math.max(0, Math.round(Number(b.unitPrice) || 0)),
      image: String(b.image ?? ""),
      active: b.active === undefined ? true : Boolean(b.active),
      sort: Math.round(Number(b.sort) || 0),
    };
    const [row] = await db.insert(wholesaleOffers).values(payload).returning();
    return Response.json({ offer: row });
  } catch {
    return Response.json({ error: "تعذّر إضافة العرض" }, { status: 500 });
  }
}
