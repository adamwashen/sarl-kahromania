import { NextRequest } from "next/server";
import { db } from "@/db";
import { wholesaleOffers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PUT(req: NextRequest, ctx: Ctx) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const { id } = await ctx.params;
    const oid = Number(id);
    if (!Number.isFinite(oid)) {
      return Response.json({ error: "معرّف غير صالح" }, { status: 400 });
    }
    const b = await req.json();
    const patch: Record<string, unknown> = {};
    if (b.name !== undefined) patch.name = String(b.name).trim();
    if (b.description !== undefined)
      patch.description = String(b.description ?? "");
    if (b.minQty !== undefined)
      patch.minQty = Math.max(1, Math.round(Number(b.minQty) || 1));
    if (b.unitPrice !== undefined)
      patch.unitPrice = Math.max(0, Math.round(Number(b.unitPrice) || 0));
    if (b.image !== undefined) patch.image = String(b.image ?? "");
    if (b.active !== undefined) patch.active = Boolean(b.active);
    if (b.sort !== undefined) patch.sort = Math.round(Number(b.sort) || 0);

    const [row] = await db
      .update(wholesaleOffers)
      .set(patch)
      .where(eq(wholesaleOffers.id, oid))
      .returning();
    if (!row)
      return Response.json({ error: "العرض غير موجود" }, { status: 404 });
    return Response.json({ offer: row });
  } catch {
    return Response.json({ error: "تعذّر تعديل العرض" }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const { id } = await ctx.params;
    await db.delete(wholesaleOffers).where(eq(wholesaleOffers.id, Number(id)));
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "تعذّر حذف العرض" }, { status: 500 });
  }
}
