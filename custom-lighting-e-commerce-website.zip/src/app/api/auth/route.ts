import { NextRequest } from "next/server";
import { ADMIN_COOKIE, isValidPassword, makeAdminToken } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    if (!body?.password || !isValidPassword(String(body.password))) {
      return Response.json({ error: "كلمة السر غير صحيحة" }, { status: 401 });
    }
    const res = Response.json({ ok: true });
    res.headers.append(
      "Set-Cookie",
      `${ADMIN_COOKIE}=${makeAdminToken()}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${60 * 60 * 24 * 7}${
        process.env.NODE_ENV === "production" ? "; Secure" : ""
      }`
    );
    return res;
  } catch {
    return Response.json({ error: "طلب غير صالح" }, { status: 400 });
  }
}

export async function DELETE() {
  const res = Response.json({ ok: true });
  res.headers.append(
    "Set-Cookie",
    `${ADMIN_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`
  );
  return res;
}
