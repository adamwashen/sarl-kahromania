import { NextRequest } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { inArray } from "drizzle-orm";
import { DEFAULT_SETTINGS } from "@/lib/defaults";
import { isAdminRequest, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

const ALLOWED_KEYS = Object.keys(DEFAULT_SETTINGS);

export async function GET() {
  try {
    // Seed any missing keys with defaults so the admin always has values to edit.
    const rows = await db
      .select()
      .from(settings)
      .where(inArray(settings.key, ALLOWED_KEYS));
    const map: Record<string, string> = { ...DEFAULT_SETTINGS };
    for (const r of rows) map[r.key] = r.value;
    const missing = ALLOWED_KEYS.filter((k) => !rows.some((r) => r.key === k));
    if (missing.length > 0) {
      await db
        .insert(settings)
        .values(
          missing.map((k) => ({ key: k, value: DEFAULT_SETTINGS[k] ?? "" }))
        )
        .onConflictDoNothing();
    }
    return Response.json({ settings: map });
  } catch {
    return Response.json({ settings: DEFAULT_SETTINGS });
  }
}

export async function PUT(req: NextRequest) {
  if (!(await isAdminRequest())) return unauthorized();
  try {
    const body = await req.json();
    const incoming: Record<string, unknown> = body?.settings ?? {};
    const ops = Object.entries(incoming)
      .filter(([k]) => ALLOWED_KEYS.includes(k))
      .map(([k, v]) => ({ key: k, value: String(v ?? "") }));
    for (const row of ops) {
      await db
        .insert(settings)
        .values(row)
        .onConflictDoUpdate({
          target: settings.key,
          set: { value: row.value },
        });
    }
    return Response.json({ ok: true, count: ops.length });
  } catch {
    return Response.json({ error: "تعذّر حفظ الإعدادات" }, { status: 500 });
  }
}
