import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Alexandria } from "next/font/google";
import "./globals.css";

const alexandria = Alexandria({
  subsets: ["arabic", "latin"],
  variable: "--font-alexandria",
  weight: ["300", "400", "500", "600", "700", "800", "900"],
});

export const metadata: Metadata = {
  title: "Sarl Kahromania — Groupe Al-Ryada | إضاءة تصنع الديكور",
  description:
    "متجر كاهرومانيا، فرع مجموعة الريادة في الجزائر — ثريات، نيون، شرائط LED وإضاءة ديكور فاخرة. الطلب والدفع عبر واتساب مع توصيل لكل الولايات.",
};

export const viewport: Viewport = {
  themeColor: "#030304",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={alexandria.variable}>
      <body className="bg-night-950 font-sans text-zinc-100 antialiased">
        {children}
      </body>
    </html>
  );
}
