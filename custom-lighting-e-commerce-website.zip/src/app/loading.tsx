import { Loader2 } from "lucide-react";

export default function Loading() {
  return (
    <div className="grid min-h-screen place-items-center bg-night-950">
      <div className="flex flex-col items-center gap-4">
        <Loader2 className="size-10 animate-spin text-ember-500" />
        <p className="text-xs font-bold tracking-[0.3em] text-zinc-600">
          SARL KAHROMANIA
        </p>
      </div>
    </div>
  );
}
