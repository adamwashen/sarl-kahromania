"use client";

import { Flame, RotateCcw } from "lucide-react";

export default function RootError({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="relative grid min-h-screen place-items-center overflow-hidden bg-night-950 p-6">
      <div className="pointer-events-none absolute -top-32 left-1/2 h-72 w-[480px] -translate-x-1/2 rounded-full bg-ember-600/15 blur-[110px]" />
      <div className="relative text-center">
        <span className="mx-auto grid size-16 place-items-center rounded-2xl bg-gradient-to-br from-ember-500/25 to-ember-600/5 text-ember-400 shadow-[inset_0_0_30px_rgba(255,122,26,0.2)]">
          <Flame className="size-8" />
        </span>
        <h1 className="mt-5 text-2xl font-black text-zinc-100">حدث خطأ غير متوقع</h1>
        <p className="mt-2 max-w-xs text-sm leading-7 text-zinc-500">
          انطفأ الضوء للحظة — أعد المحاولة وسيعود كل شيء للعمل.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={reset}
            className="flex items-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-7 py-3.5 text-sm font-black text-night-950 transition-transform duration-200 hover:scale-[1.03] active:scale-95"
          >
            <RotateCcw className="size-4" />
            إعادة المحاولة
          </button>
          <a
            href="/"
            className="rounded-2xl border border-white/10 px-7 py-3.5 text-sm font-bold text-zinc-300 transition-colors hover:border-ember-500/40 hover:text-ember-300"
          >
            العودة إلى المتجر
          </a>
        </div>
      </div>
    </div>
  );
}
