import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
} from "drizzle-orm/pg-core";

export type OrderItem = {
  id: number;
  name: string;
  price: number;
  qty: number;
  image?: string;
};

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  price: integer("price").notNull().default(0),
  oldPrice: integer("old_price"),
  image: text("image").notNull().default(""),
  category: text("category").notNull().default("معلّقات"),
  badge: text("badge"),
  featured: boolean("featured").notNull().default(false),
  inStock: boolean("in_stock").notNull().default(true),
  sort: integer("sort").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull().default(""),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull().default(""),
  phone: text("phone").notNull().default(""),
  wilaya: text("wilaya").notNull().default(""),
  address: text("address").notNull().default(""),
  notes: text("notes").notNull().default(""),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  total: integer("total").notNull().default(0),
  status: text("status").notNull().default("new"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const wholesaleOffers = pgTable("wholesale_offers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  minQty: integer("min_qty").notNull().default(10),
  unitPrice: integer("unit_price").notNull().default(0),
  image: text("image").notNull().default(""),
  active: boolean("active").notNull().default(true),
  sort: integer("sort").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
export type Order = typeof orders.$inferSelect;
export type WholesaleOffer = typeof wholesaleOffers.$inferSelect;
export type NewWholesaleOffer = typeof wholesaleOffers.$inferInsert;
