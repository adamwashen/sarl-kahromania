import type { NewProduct, NewWholesaleOffer } from "@/db/schema";

export const DEFAULT_SETTINGS: Record<string, string> = {
  whatsapp: "213540588197",
  phoneDisplay: "0550 12 34 56",
  email: "contact@kahromania.dz",
  address: "الجزائر العاصمة، الجزائر",
  instagram: "https://instagram.com/kahromania.dz",
  facebook: "https://facebook.com/kahromania.dz",
  announcement:
    "توصيل سريع نحو 58 ولاية — الطلب والدفع حصرياً عبر واتساب",
  heroKicker: "Groupe Al-Ryada — Sarl Kahromania",
  heroTitle: "إضاءة تُعيد رسم",
  heroAccent: "ملامح الديكور",
  heroSubtitle:
    "في Sarl Kahromania، فرع مجموعة الريادة بالجزائر، ننتقي لك الأضواء التي تُحدث الفرق: ثريات، نيون، شرائط LED وإضاءة ذكية تصنع أجواءً لا تُنسى.",
  aboutTitle: "Sarl Kahromania — الذراع المضيء لـ Groupe Al-Ryada",
  aboutText:
    "من قلب الجزائر، تخصّصت Sarl Kahromania في فنّ الإضاءة الديكورية: قطع مختارة بعناية من الثريات، المعلّقات، النيون والإضاءة الذكية التي ترفع قيمة أي مساحة. نرافقك من الاختيار حتى التركيب، بجودة مضمونة وتصاميم تواكب أحدث صيحات الديكور العالمية.",
  deliveryText:
    "التوصيل متوفر لجميع الولايات — الطلب والتأكيد يتمان حصرياً عبر واتساب.",
  wholesaleKicker: "للمهنيين وأصحاب المحلات",
  wholesaleTitle: "قسم الجملة — أسعار تفضيلية للكميات",
  wholesaleSubtitle:
    "يزوّد فرع Groupe Al-Ryada محلات الإنارة ومكاتب الديكور والمقاولين بكميات كبيرة بأسعار تنافسية، مع توثيق رسمي وأولوية في التجهيز والشحن لكل الولايات.",
  marquee:
    "ثريات فاخرة • نيون مخصص • شرائط LED • إضاءة ذكية • أضواء جدارية • مصابيح أرضية • تصاميم حسب الطلب",
  footerText: "© Sarl Kahromania — Groupe Al-Ryada. جميع الحقوق محفوظة.",
};

export const SEED_PRODUCTS: NewProduct[] = [
  {
    name: "ثريا حلزونية ذهبية Spiral Luxe",
    description:
      "ثريا حلزونية من حلقات الألمنيوم الذهبي بإضاءة LED دافئة، تمنح المدخل أو الصالون حضوراً ملكياً مع تحكم في شدة الإضاءة.",
    price: 18500,
    oldPrice: 24000,
    image: "/images/products/p1.jpg",
    category: "ثريات",
    badge: "الأكثر مبيعاً",
    featured: true,
    sort: 1,
  },
  {
    name: "نيون الهلال والنجمة",
    description:
      "لوحة نيون بتصميم هلال ونجمة بتوهج برتقالي دافئ، مثالية لغرف النوم وزوايا التصوير، استهلاك منخفض وعمر طويل.",
    price: 4900,
    oldPrice: 6500,
    image: "/images/products/p2.jpg",
    category: "نيون",
    badge: "جديد",
    featured: true,
    sort: 2,
  },
  {
    name: "شريط LED مخفي للأسقف — 5 أمتار",
    description:
      "شريط إضاءة LED دافئ بطول 5 أمتار مع لاصق قوي ومحوّل، لإضاءة سينمائية مخفية للأسقف المستعارة والأثاث.",
    price: 3200,
    oldPrice: null,
    image: "/images/products/p3.jpg",
    category: "شرائط LED",
    badge: "عرض خاص",
    featured: false,
    sort: 3,
  },
  {
    name: "مصباح طاولة إديسون الصناعي",
    description:
      "مصباح طاولة بطابع صناعي، قفص معدني أسود ولمبة إديسون عنبرية تضيف دفئاً راقياً للمكاتب والطاولات الجانبية.",
    price: 5400,
    oldPrice: 7200,
    image: "/images/products/p4.jpg",
    category: "مصابيح طاولة",
    badge: null,
    featured: true,
    sort: 4,
  },
  {
    name: "معلّقة الحلقة العصرية",
    description:
      "معلّقة دائرية بتصميم مينيمال بحواف ذهبية وإضاءة ناعمة متجانسة، تناسب طاولات الطعام والممرات الفاخرة.",
    price: 12900,
    oldPrice: null,
    image: "/images/products/p5.jpg",
    category: "معلّقات",
    badge: null,
    featured: false,
    sort: 5,
  },
  {
    name: "إنارة جدارية كريستال",
    description:
      "إنارة جدارية من قضبان الكريستال تعكس الضوء الدافئ بانكسارات ساحرة، لمسة فندقية فاخرة للممرات وغرف النوم.",
    price: 7800,
    oldPrice: 9800,
    image: "/images/products/p6.jpg",
    category: "أضواء جدارية",
    badge: "فاخر",
    featured: true,
    sort: 6,
  },
  {
    name: "مصباح أرضي زاوية بتوهج متدرج",
    description:
      "مصباح زاوية عمودي بتحكم عن بعد، يغمر الجدار بتوهج برتقالي متدرج يحوّل أي ركن إلى لوحة فنية.",
    price: 9900,
    oldPrice: 12500,
    image: "/images/products/p7.jpg",
    category: "مصابيح أرضية",
    badge: "الأكثر طلباً",
    featured: true,
    sort: 7,
  },
  {
    name: "معلّقة هندسية أسود × ذهبي",
    description:
      "قفص هندسي أسود بمقبس ذهبي ولمبة عنبرية، طابع لوفت صناعي فاخر مثالي فوق بار المطبخ أو طاولة القهوة.",
    price: 6700,
    oldPrice: null,
    image: "/images/products/p8.jpg",
    category: "معلّقات",
    badge: null,
    featured: false,
    sort: 8,
  },
];

export const SEED_WHOLESALE: NewWholesaleOffer[] = [
  {
    name: "لفة شريط LED احترافي — 50 متر",
    description:
      "شريط إضاءة دافئ 2835 عالي الكثافة، مقاوم للرطوبة، جاهز للقص والتركيب — الخيار الأول لمشاريع المحلات والواجهات.",
    minQty: 5,
    unitPrice: 14500,
    image: "/images/products/p3.jpg",
    sort: 1,
  },
  {
    name: "علبة لمبات إديسون عنبرية — 20 لمبة",
    description:
      "لمبات G80 بخيوط إضاءة كلاسيكية وتوهج عنبري دافئ، عمر طويل — مثالية للمقاهي والمطاعم والديكور الصناعي.",
    minQty: 3,
    unitPrice: 9800,
    image: "/images/products/p4.jpg",
    sort: 2,
  },
  {
    name: "دفعة نيون مخصص حسب الطلب",
    description:
      "نصنع تصميمك الخاص بالنيون (شعارات، عبارات، أشكال) بجودة تصدير — السعر للقطعة الواحدة ويُحسب نهائياً حسب التصميم.",
    minQty: 10,
    unitPrice: 3900,
    image: "/images/products/p2.jpg",
    sort: 3,
  },
  {
    name: "دفعة معلّقات هندسية — 12 قطعة",
    description:
      "المعلّقة الهندسية أسود × ذهبي الأكثر طلباً، مغلفة بعناية وجاهزة لإعادة البيع أو تركيب المشاريع الفندقية والمطاعم.",
    minQty: 2,
    unitPrice: 69000,
    image: "/images/products/p8.jpg",
    sort: 4,
  },
];

export const CATEGORIES = [
  "ثريات",
  "معلّقات",
  "نيون",
  "شرائط LED",
  "أضواء جدارية",
  "مصابيح طاولة",
  "مصابيح أرضية",
];
