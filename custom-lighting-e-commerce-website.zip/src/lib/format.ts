export function formatDZD(n: number): string {
  const grouped = new Intl.NumberFormat("fr-FR", {
    maximumFractionDigits: 0,
  }).format(Math.round(n || 0));
  return `${grouped} دج`;
}

export function digitsOnly(s: string): string {
  return s.replace(/[^\d]/g, "");
}

export function buildWhatsAppLink(phone: string, message: string): string {
  const num = digitsOnly(phone).replace(/^0+/, "");
  const withCc = num.startsWith("213") ? num : `213${num}`;
  return `https://wa.me/${withCc}?text=${encodeURIComponent(message)}`;
}

export function cn(...parts: Array<string | false | null | undefined>) {
  return parts.filter(Boolean).join(" ");
}
