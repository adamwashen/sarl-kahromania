import { createHmac } from "crypto";
import { cookies } from "next/headers";

export const ADMIN_PASSWORD = "1245";
export const ADMIN_COOKIE = "kr_admin";

function secret() {
  return process.env.ADMIN_SECRET || "kahromania-groupe-alryada-secret";
}

export function makeAdminToken() {
  return createHmac("sha256", secret())
    .update(`admin::${ADMIN_PASSWORD}`)
    .digest("hex");
}

export function isValidPassword(pw: string) {
  return pw.trim() === ADMIN_PASSWORD;
}

export async function isAdminRequest(): Promise<boolean> {
  try {
    const store = await cookies();
    return store.get(ADMIN_COOKIE)?.value === makeAdminToken();
  } catch {
    return false;
  }
}

export function unauthorized() {
  return Response.json({ error: "غير مصرّح" }, { status: 401 });
}
