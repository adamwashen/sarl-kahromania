"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ChevronDown,
  ClipboardList,
  MapPin,
  Phone,
  Trash2,
  User,
} from "lucide-react";
import type { Order } from "@/db/schema";
import { cn, formatDZD } from "@/lib/format";

const STATUS: Record<string, { label: string; cls: string }> = {
  new: { label: "جديد", cls: "border-ember-500/40 bg-ember-500/15 text-ember-300" },
  confirmed: { label: "مؤكد", cls: "border-sky-500/40 bg-sky-500/15 text-sky-300" },
  delivered: {
    label: "تم التوصيل",
    cls: "border-emerald-500/40 bg-emerald-500/15 text-emerald-300",
  },
  cancelled: { label: "ملغي", cls: "border-zinc-500/40 bg-zinc-500/15 text-zinc-400" },
};

function fmtDate(d: string | Date) {
  const dt = new Date(d);
  return `${dt.toLocaleDateString("fr-FR")} — ${dt.toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
  })}`;
}

export default function OrdersTab({
  orders,
  reload,
  notify,
}: {
  orders: Order[];
  reload: () => Promise<void>;
  notify: (msg: string) => void;
}) {
  const [openId, setOpenId] = useState<number | null>(null);
  const [confirmDel, setConfirmDel] = useState<number | null>(null);
  const [busy, setBusy] = useState<number | null>(null);

  async function setStatus(id: number, status: string) {
    setBusy(id);
    try {
      await fetch(`/api/orders/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      await reload();
      notify("تم تحديث حالة الطلب");
    } finally {
      setBusy(null);
    }
  }

  async function remove(id: number) {
    setBusy(id);
    try {
      await fetch(`/api/orders/${id}`, { method: "DELETE" });
      setConfirmDel(null);
      await reload();
      notify("تم حذف الطلب");
    } finally {
      setBusy(null);
    }
  }

  if (orders.length === 0) {
    return (
      <div className="flex flex-col items-center gap-3 rounded-3xl border border-dashed border-white/10 bg-night-900/40 py-20 text-center">
        <ClipboardList className="size-12 text-zinc-700" />
        <p className="text-sm font-extrabold text-zinc-300">لا توجد طلبات بعد</p>
        <p className="max-w-xs text-[11px] leading-5 text-zinc-600">
          عندما يضغط الزبون "تأكيد الطلب عبر واتساب" يُسجَّل الطلب هنا تلقائياً.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {orders.map((o) => {
        const st = STATUS[o.status] ?? STATUS.new;
        const open = openId === o.id;
        return (
          <motion.div
            key={o.id}
            layout
            className="overflow-hidden rounded-2xl border border-white/10 bg-night-900/60"
          >
            <div className="flex flex-wrap items-center gap-3 px-5 py-4">
              <button
                onClick={() => setOpenId(open ? null : o.id)}
                className="flex min-w-0 flex-1 flex-wrap items-center gap-x-5 gap-y-2 text-start"
              >
                <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-ember-500/10 text-sm font-black text-ember-400">
                  #{o.id}
                </span>
                <span className="min-w-0">
                  <span className="flex items-center gap-1.5 text-sm font-extrabold">
                    <User className="size-3.5 text-zinc-500" />
                    {o.customerName || "زبون"}
                  </span>
                  <span className="mt-0.5 block text-[11px] text-zinc-600">
                    {fmtDate(o.createdAt)}
                  </span>
                </span>
                <span className="hidden items-center gap-1.5 text-xs text-zinc-400 sm:flex" dir="ltr">
                  <Phone className="size-3.5 text-zinc-500" />
                  {o.phone}
                </span>
                <span className="hidden items-center gap-1.5 text-xs text-zinc-400 md:flex">
                  <MapPin className="size-3.5 text-zinc-500" />
                  {o.wilaya}
                </span>
              </button>

              <span className="text-base font-black text-ember-400">
                {formatDZD(o.total)}
              </span>

              <select
                value={o.status}
                disabled={busy === o.id}
                onChange={(e) => setStatus(o.id, e.target.value)}
                className={cn(
                  "cursor-pointer appearance-none rounded-xl border px-3 py-2 text-[11px] font-black outline-none transition-colors",
                  st.cls
                )}
              >
                {Object.entries(STATUS).map(([k, v]) => (
                  <option key={k} value={k} className="bg-night-900 text-zinc-100">
                    {v.label}
                  </option>
                ))}
              </select>

              {confirmDel === o.id ? (
                <button
                  onClick={() => remove(o.id)}
                  className="rounded-xl border border-red-500/50 bg-red-500/15 px-3 py-2 text-[11px] font-black text-red-300"
                >
                  تأكيد الحذف؟
                </button>
              ) : (
                <button
                  onClick={() => {
                    setConfirmDel(o.id);
                    setTimeout(() => setConfirmDel((c) => (c === o.id ? null : c)), 3000);
                  }}
                  className="grid size-9 place-items-center rounded-xl border border-white/10 text-zinc-500 transition-colors hover:border-red-500/40 hover:text-red-400"
                >
                  <Trash2 className="size-4" />
                </button>
              )}

              <button
                onClick={() => setOpenId(open ? null : o.id)}
                className="grid size-9 place-items-center rounded-xl border border-white/10 text-zinc-400"
              >
                <ChevronDown
                  className={cn("size-4 transition-transform", open && "rotate-180")}
                />
              </button>
            </div>

            <AnimatePresence initial={false}>
              {open && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden border-t border-white/5"
                >
                  <div className="space-y-2 px-5 py-4">
                    <div className="grid gap-2 sm:grid-cols-2">
                      <p className="flex items-center gap-2 text-xs text-zinc-400 sm:hidden" dir="ltr">
                        <Phone className="size-3.5 text-zinc-500" /> {o.phone}
                      </p>
                      <p className="text-xs text-zinc-400">
                        <span className="font-bold text-zinc-500">الولاية:</span> {o.wilaya}
                        {o.address ? ` — ${o.address}` : ""}
                      </p>
                      {o.notes && (
                        <p className="text-xs text-zinc-400">
                          <span className="font-bold text-zinc-500">ملاحظات:</span> {o.notes}
                        </p>
                      )}
                    </div>
                    <div className="mt-2 rounded-xl border border-white/5 bg-night-950/50 p-3">
                      {o.items.map((it, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-3 border-b border-white/5 py-2 text-xs last:border-0"
                        >
                          {it.image && (
                            <img
                              src={it.image}
                              alt=""
                              className="size-9 rounded-lg border border-white/10 object-cover"
                            />
                          )}
                          <span className="flex-1 truncate font-bold text-zinc-300">
                            {it.name}
                          </span>
                          <span className="text-zinc-500">× {it.qty}</span>
                          <span className="w-24 text-end font-black text-ember-400">
                            {formatDZD(it.price * it.qty)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        );
      })}
    </div>
  );
}
