"use client";

import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Boxes,
  ImagePlus,
  Loader2,
  Pencil,
  Plus,
  Save,
  Trash2,
  X,
} from "lucide-react";
import type { WholesaleOffer } from "@/db/schema";
import { cn, formatDZD } from "@/lib/format";
import { Field, InlinePrice, Toggle, adminInput } from "./ui";

/* ------------------------------- Form modal ------------------------------- */

function OfferForm({
  initial,
  onClose,
  onSaved,
}: {
  initial: WholesaleOffer | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [minQty, setMinQty] = useState(String(initial?.minQty ?? 10));
  const [unitPrice, setUnitPrice] = useState(String(initial?.unitPrice ?? ""));
  const [image, setImage] = useState(initial?.image ?? "");
  const [active, setActive] = useState(initial?.active ?? true);
  const [sort, setSort] = useState(String(initial?.sort ?? 0));
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function upload(file: File) {
    setUploading(true);
    setError("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const d = await res.json();
      if (d.url) setImage(d.url);
      else setError(d.error || "تعذّر رفع الصورة");
    } catch {
      setError("تعذّر رفع الصورة");
    } finally {
      setUploading(false);
    }
  }

  async function save() {
    setError("");
    if (name.trim().length < 2) return setError("أدخل اسم العرض.");
    if ((Number(unitPrice) || 0) <= 0) return setError("أدخل سعر وحدة صحيحاً.");
    setSaving(true);
    const payload = {
      name: name.trim(),
      description: description.trim(),
      minQty: Math.max(1, Number(minQty) || 1),
      unitPrice: Number(unitPrice) || 0,
      image,
      active,
      sort: Number(sort) || 0,
    };
    try {
      const res = await fetch(
        initial ? `/api/wholesale/${initial.id}` : "/api/wholesale",
        {
          method: initial ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) throw new Error();
      onSaved();
    } catch {
      setError("تعذّر الحفظ، حاول مجدداً.");
      setSaving(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-[70] grid place-items-center overflow-y-auto bg-night-950/85 p-4 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, y: 36, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.97 }}
        transition={{ type: "spring", stiffness: 260, damping: 26 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl overflow-hidden rounded-3xl border border-white/10 bg-night-900 shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-white/5 px-6 py-4">
          <h3 className="text-base font-black">
            {initial ? "تعديل عرض الجملة" : "إضافة عرض جملة جديد"}
          </h3>
          <button
            onClick={onClose}
            className="grid size-9 place-items-center rounded-full border border-white/10 text-zinc-400 transition-colors hover:text-ember-400"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="grid gap-6 p-6 sm:grid-cols-[210px_1fr]">
          {/* Image column */}
          <div>
            <div className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-white/10 bg-night-950">
              {image ? (
                <img src={image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full place-items-center text-zinc-700">
                  <ImagePlus className="size-9" />
                </div>
              )}
              {uploading && (
                <div className="absolute inset-0 grid place-items-center bg-night-950/70">
                  <Loader2 className="size-7 animate-spin text-ember-400" />
                </div>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) upload(f);
                e.target.value = "";
              }}
            />
            <button
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-ember-500/30 bg-ember-500/10 py-2.5 text-xs font-black text-ember-300 transition-colors hover:bg-ember-500/20"
            >
              <ImagePlus className="size-4" />
              رفع صورة
            </button>
            <input
              dir="ltr"
              value={image}
              onChange={(e) => setImage(e.target.value)}
              placeholder="https://…"
              className={`${adminInput} mt-2 text-left text-xs`}
            />
          </div>

          {/* Fields column */}
          <div className="space-y-4">
            <Field label="اسم العرض">
              <input
                className={adminInput}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: لفة شريط LED احترافي — 50 متر"
              />
            </Field>
            <Field label="الوصف">
              <textarea
                rows={3}
                className={`${adminInput} resize-none`}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="تفاصيل العرض والكميات…"
              />
            </Field>
            <div className="grid grid-cols-3 gap-3">
              <Field label="سعر الوحدة (دج)">
                <input
                  type="number"
                  dir="ltr"
                  className={`${adminInput} text-left`}
                  value={unitPrice}
                  onChange={(e) => setUnitPrice(e.target.value)}
                  placeholder="0"
                />
              </Field>
              <Field label="الحد الأدنى للكمية">
                <input
                  type="number"
                  dir="ltr"
                  className={`${adminInput} text-left`}
                  value={minQty}
                  onChange={(e) => setMinQty(e.target.value)}
                />
              </Field>
              <Field label="الترتيب">
                <input
                  type="number"
                  dir="ltr"
                  className={`${adminInput} text-left`}
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                />
              </Field>
            </div>
            <div className="rounded-2xl border border-white/5 bg-white/[0.02] px-4 py-3">
              <Toggle checked={active} onChange={setActive} label="عرض ظاهر في المتجر" />
            </div>
            {error && (
              <p className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-[11px] font-bold text-red-300">
                {error}
              </p>
            )}
            <button
              onClick={save}
              disabled={saving || uploading}
              className="btn-sheen flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 py-3.5 text-sm font-black text-night-950 transition-transform duration-200 hover:scale-[1.01] active:scale-95 disabled:opacity-60"
            >
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              {initial ? "حفظ التعديلات" : "إضافة العرض"}
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* --------------------------------- Tab ----------------------------------- */

export default function WholesaleTab({
  offers,
  reload,
  notify,
}: {
  offers: WholesaleOffer[];
  reload: () => Promise<void>;
  notify: (msg: string) => void;
}) {
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<WholesaleOffer | null>(null);
  const [confirmDel, setConfirmDel] = useState<number | null>(null);
  const [busy, setBusy] = useState<number | null>(null);

  async function patch(id: number, data: Record<string, unknown>) {
    setBusy(id);
    try {
      await fetch(`/api/wholesale/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      await reload();
    } finally {
      setBusy(null);
    }
  }

  async function remove(id: number) {
    setBusy(id);
    try {
      await fetch(`/api/wholesale/${id}`, { method: "DELETE" });
      setConfirmDel(null);
      await reload();
      notify("تم حذف العرض");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs leading-6 text-zinc-500">
          عروض الجملة تظهر في قسم خاص داخل المتجر مع حاسبة كميات وطلب مباشر عبر
          واتساب.
        </p>
        <button
          onClick={() => {
            setEditing(null);
            setFormOpen(true);
          }}
          className="btn-sheen flex items-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-6 py-3 text-xs font-black text-night-950 shadow-[0_12px_32px_-10px_rgba(255,122,26,0.7)] transition-transform duration-200 hover:scale-[1.03] active:scale-95"
        >
          <Plus className="size-4" />
          إضافة عرض جملة
        </button>
      </div>

      <div className="space-y-3">
        {offers.map((o) => (
          <motion.div
            key={o.id}
            layout
            className={cn(
              "flex flex-wrap items-center gap-4 rounded-2xl border border-white/10 bg-night-900/60 p-4",
              busy === o.id && "opacity-60"
            )}
          >
            <div className="relative size-16 shrink-0 overflow-hidden rounded-xl border border-white/10 bg-night-950">
              {o.image ? (
                <img src={o.image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full place-items-center text-zinc-700">
                  <Boxes className="size-5" />
                </div>
              )}
            </div>

            <div className="min-w-44 flex-1">
              <p className="truncate text-sm font-extrabold">{o.name}</p>
              <div className="mt-1.5 flex flex-wrap items-center gap-2">
                <span className="rounded-full border border-ember-500/30 bg-ember-500/10 px-2.5 py-0.5 text-[10px] font-black text-ember-300">
                  حد أدنى: {o.minQty}
                </span>
                {!o.active && (
                  <span className="rounded-full bg-zinc-500/15 px-2.5 py-0.5 text-[10px] font-black text-zinc-400">
                    مخفي عن المتجر
                  </span>
                )}
              </div>
            </div>

            <div className="min-w-32 text-end">
              <InlinePrice
                price={o.unitPrice}
                onSave={async (v) => {
                  await patch(o.id, { unitPrice: v });
                  notify("تم تحديث سعر الوحدة");
                }}
              />
              <p className="mt-1 text-[11px] text-zinc-600">سعر الوحدة</p>
            </div>

            <div className="flex items-center gap-3">
              <Toggle
                checked={o.active}
                onChange={(v) => patch(o.id, { active: v })}
                label="ظاهر"
              />
              <button
                onClick={() => {
                  setEditing(o);
                  setFormOpen(true);
                }}
                className="grid size-9 place-items-center rounded-xl border border-white/10 text-zinc-400 transition-colors hover:border-ember-500/40 hover:text-ember-300"
              >
                <Pencil className="size-4" />
              </button>
              {confirmDel === o.id ? (
                <button
                  onClick={() => remove(o.id)}
                  className="rounded-xl border border-red-500/50 bg-red-500/15 px-3 py-2 text-[11px] font-black text-red-300"
                >
                  تأكيد الحذف؟
                </button>
              ) : (
                <button
                  onClick={() => {
                    setConfirmDel(o.id);
                    setTimeout(
                      () => setConfirmDel((c) => (c === o.id ? null : c)),
                      3000
                    );
                  }}
                  className="grid size-9 place-items-center rounded-xl border border-white/10 text-zinc-500 transition-colors hover:border-red-500/40 hover:text-red-400"
                >
                  <Trash2 className="size-4" />
                </button>
              )}
            </div>
          </motion.div>
        ))}

        {offers.length === 0 && (
          <div className="rounded-3xl border border-dashed border-white/10 bg-night-900/40 py-16 text-center">
            <Boxes className="mx-auto size-10 text-zinc-700" />
            <p className="mt-3 text-sm font-bold text-zinc-500">
              لا توجد عروض جملة — أضف أول عرض من الزر أعلاه
            </p>
          </div>
        )}
      </div>

      <AnimatePresence>
        {formOpen && (
          <OfferForm
            initial={editing}
            onClose={() => setFormOpen(false)}
            onSaved={async () => {
              setFormOpen(false);
              await reload();
              notify(editing ? "تم تحديث العرض" : "تمت إضافة العرض");
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
