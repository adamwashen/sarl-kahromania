"use client";

import { useState } from "react";
import { Loader2, Save } from "lucide-react";
import { Field, adminInput } from "./ui";

export default function SettingsTab({
  settings,
  notify,
}: {
  settings: Record<string, string>;
  notify: (msg: string) => void;
}) {
  const [form, setForm] = useState<Record<string, string>>(settings);
  const [saving, setSaving] = useState(false);

  const set = (k: string) => (v: string) =>
    setForm((f) => ({ ...f, [k]: v }));

  async function save() {
    setSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: form }),
      });
      if (!res.ok) throw new Error();
      notify("تم حفظ الإعدادات بنجاح — أعد تحميل المتجر لرؤية التغييرات");
    } catch {
      notify("تعذّر حفظ الإعدادات");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Contact */}
      <section className="rounded-3xl border border-white/10 bg-night-900/60 p-6">
        <h3 className="text-sm font-black text-ember-300">التواصل واستقبال الطلبات</h3>
        <p className="mt-1 text-[11px] text-zinc-500">
          رقم واتساب هو الرقم الذي تصل عليه طلبات الزبائن.
        </p>
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <Field
            label="رقم واتساب (بالصيغة الدولية)"
            hint="مثال: 213550123456 — بدون + وبدون أصفار البداية"
          >
            <input
              dir="ltr"
              inputMode="numeric"
              className={`${adminInput} text-left`}
              value={form.whatsapp ?? ""}
              onChange={(e) => set("whatsapp")(e.target.value)}
            />
          </Field>
          <Field label="رقم الهاتف المعروض في الموقع">
            <input
              dir="ltr"
              className={`${adminInput} text-left`}
              value={form.phoneDisplay ?? ""}
              onChange={(e) => set("phoneDisplay")(e.target.value)}
            />
          </Field>
          <Field label="البريد الإلكتروني">
            <input
              dir="ltr"
              className={`${adminInput} text-left`}
              value={form.email ?? ""}
              onChange={(e) => set("email")(e.target.value)}
            />
          </Field>
          <Field label="العنوان">
            <input
              className={adminInput}
              value={form.address ?? ""}
              onChange={(e) => set("address")(e.target.value)}
            />
          </Field>
          <Field label="رابط إنستغرام">
            <input
              dir="ltr"
              className={`${adminInput} text-left`}
              value={form.instagram ?? ""}
              onChange={(e) => set("instagram")(e.target.value)}
            />
          </Field>
          <Field label="رابط فيسبوك">
            <input
              dir="ltr"
              className={`${adminInput} text-left`}
              value={form.facebook ?? ""}
              onChange={(e) => set("facebook")(e.target.value)}
            />
          </Field>
        </div>
      </section>

      {/* Texts */}
      <section className="rounded-3xl border border-white/10 bg-night-900/60 p-6">
        <h3 className="text-sm font-black text-ember-300">نصوص الواجهة</h3>
        <p className="mt-1 text-[11px] text-zinc-500">
          عدّل العناوين والفقرات الظاهرة في المتجر.
        </p>
        <div className="mt-5 grid gap-4">
          <Field label="شريط الإعلان العلوي">
            <input
              className={adminInput}
              value={form.announcement ?? ""}
              onChange={(e) => set("announcement")(e.target.value)}
            />
          </Field>
          <Field label="الشريط المتحرك (افصل بين العبارات بـ •)">
            <input
              className={adminInput}
              value={form.marquee ?? ""}
              onChange={(e) => set("marquee")(e.target.value)}
            />
          </Field>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="العبارة الصغيرة فوق العنوان">
              <input
                className={adminInput}
                value={form.heroKicker ?? ""}
                onChange={(e) => set("heroKicker")(e.target.value)}
              />
            </Field>
            <Field label="العنوان الرئيسي — الجزء الأول">
              <input
                className={adminInput}
                value={form.heroTitle ?? ""}
                onChange={(e) => set("heroTitle")(e.target.value)}
              />
            </Field>
            <Field label="العنوان الرئيسي — الجزء الملوّن">
              <input
                className={adminInput}
                value={form.heroAccent ?? ""}
                onChange={(e) => set("heroAccent")(e.target.value)}
              />
            </Field>
          </div>
          <Field label="الوصف تحت العنوان الرئيسي">
            <textarea
              rows={3}
              className={`${adminInput} resize-none`}
              value={form.heroSubtitle ?? ""}
              onChange={(e) => set("heroSubtitle")(e.target.value)}
            />
          </Field>

          <div className="grid gap-4 rounded-2xl border border-ember-500/15 bg-ember-500/[0.03] p-4">
            <p className="text-[11px] font-black text-ember-300">
              قسم البيع بالجملة (يظهر بين المنتجات وقسم كيف تطلب)
            </p>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="العبارة الصغيرة فوق عنوان القسم">
                <input
                  className={adminInput}
                  value={form.wholesaleKicker ?? ""}
                  onChange={(e) => set("wholesaleKicker")(e.target.value)}
                />
              </Field>
              <Field label="عنوان قسم الجملة">
                <input
                  className={adminInput}
                  value={form.wholesaleTitle ?? ""}
                  onChange={(e) => set("wholesaleTitle")(e.target.value)}
                />
              </Field>
            </div>
            <Field label="وصف قسم الجملة">
              <textarea
                rows={3}
                className={`${adminInput} resize-none`}
                value={form.wholesaleSubtitle ?? ""}
                onChange={(e) => set("wholesaleSubtitle")(e.target.value)}
              />
            </Field>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="عنوان قسم (من نحن)">
              <input
                className={adminInput}
                value={form.aboutTitle ?? ""}
                onChange={(e) => set("aboutTitle")(e.target.value)}
              />
            </Field>
            <Field label="نص التوصيل">
              <input
                className={adminInput}
                value={form.deliveryText ?? ""}
                onChange={(e) => set("deliveryText")(e.target.value)}
              />
            </Field>
          </div>
          <Field label="فقرة (من نحن)">
            <textarea
              rows={4}
              className={`${adminInput} resize-none`}
              value={form.aboutText ?? ""}
              onChange={(e) => set("aboutText")(e.target.value)}
            />
          </Field>
          <Field label="نص الفوتر السفلي">
            <input
              className={adminInput}
              value={form.footerText ?? ""}
              onChange={(e) => set("footerText")(e.target.value)}
            />
          </Field>
        </div>
      </section>

      <div className="sticky bottom-4 flex justify-end">
        <button
          onClick={save}
          disabled={saving}
          className="btn-sheen flex items-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-8 py-3.5 text-sm font-black text-night-950 shadow-[0_16px_40px_-12px_rgba(255,122,26,0.7)] transition-transform duration-200 hover:scale-[1.02] active:scale-95 disabled:opacity-60"
        >
          {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
          حفظ كل التغييرات
        </button>
      </div>
    </div>
  );
}
