"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Boxes,
  ClipboardList,
  Coins,
  ExternalLink,
  Flame,
  Loader2,
  Lock,
  LogOut,
  Package,
  RefreshCw,
  Settings2,
  ShieldCheck,
  TriangleAlert,
} from "lucide-react";
import type { Order, Product, WholesaleOffer } from "@/db/schema";
import { DEFAULT_SETTINGS } from "@/lib/defaults";
import { cn, formatDZD } from "@/lib/format";
import ProductsTab from "./ProductsTab";
import WholesaleTab from "./WholesaleTab";
import OrdersTab from "./OrdersTab";
import SettingsTab from "./SettingsTab";
import { Toast, type ToastState } from "../store/ui";

type Tab = "products" | "wholesale" | "orders" | "settings";

export default function AdminApp() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [tab, setTab] = useState<Tab>("products");
  const [products, setProducts] = useState<Product[]>([]);
  const [wholesale, setWholesale] = useState<WholesaleOffer[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [settings, setSettings] = useState<Record<string, string>>(DEFAULT_SETTINGS);
  const [loadingData, setLoadingData] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [toast, setToast] = useState<ToastState>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [pw, setPw] = useState("");
  const [err, setErr] = useState(false);
  const [busy, setBusy] = useState(false);

  const notify = useCallback((text: string) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), text });
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }, []);

  useEffect(() => {
    fetch("/api/auth/me", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setAuthed(!!d.authed))
      .catch(() => setAuthed(false));
  }, []);

  const loadAll = useCallback(async () => {
    setRefreshing(true);
    try {
      const [p, o, s, w] = await Promise.all([
        fetch("/api/products", { cache: "no-store" }).then((r) => r.json()),
        fetch("/api/orders", { cache: "no-store" }).then((r) => r.json()),
        fetch("/api/settings", { cache: "no-store" }).then((r) => r.json()),
        fetch("/api/wholesale", { cache: "no-store" }).then((r) => r.json()),
      ]);
      setProducts(p.products ?? []);
      setOrders(o.orders ?? []);
      setWholesale(w.offers ?? []);
      if (s?.settings) setSettings({ ...DEFAULT_SETTINGS, ...s.settings });
    } catch {
      /* keep old data */
    } finally {
      setRefreshing(false);
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    if (authed) loadAll();
  }, [authed, loadAll]);

  async function login(e: React.FormEvent) {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setErr(false);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      });
      if (res.ok) setAuthed(true);
      else {
        setErr(true);
        setPw("");
      }
    } catch {
      setErr(true);
    } finally {
      setBusy(false);
    }
  }

  async function logout() {
    await fetch("/api/auth", { method: "DELETE" });
    setAuthed(false);
  }

  /* ------------------------------ Boot spinner ----------------------------- */
  if (authed === null) {
    return (
      <div className="grid min-h-screen place-items-center bg-night-950">
        <Loader2 className="size-10 animate-spin text-ember-500" />
      </div>
    );
  }

  /* -------------------------------- Login gate ----------------------------- */
  if (!authed) {
    return (
      <div className="relative grid min-h-screen place-items-center overflow-hidden bg-night-950 p-4">
        <div className="pointer-events-none absolute -top-32 left-1/2 h-72 w-[480px] -translate-x-1/2 rounded-full bg-ember-600/15 blur-[110px]" />
        <form
          onSubmit={login}
          className="relative w-full max-w-sm rounded-3xl border border-white/10 bg-night-900/80 p-8 text-center shadow-2xl backdrop-blur"
        >
          <div className="mx-auto grid size-16 place-items-center rounded-2xl bg-gradient-to-br from-ember-500/25 to-ember-600/5 text-ember-400 shadow-[inset_0_0_30px_rgba(255,122,26,0.2)]">
            <ShieldCheck className="size-8" />
          </div>
          <h1 className="mt-5 text-xl font-black">لوحة تحكم كاهرومانيا</h1>
          <p className="mt-1.5 text-xs leading-6 text-zinc-500">
            Sarl Kahromania — Groupe Al-Ryada
          </p>
          <div className="relative mt-6">
            <Lock className="absolute right-4 top-1/2 size-4 -translate-y-1/2 text-zinc-600" />
            <input
              type="password"
              inputMode="numeric"
              dir="ltr"
              autoFocus
              value={pw}
              onChange={(e) => {
                setPw(e.target.value);
                setErr(false);
              }}
              placeholder="••••"
              className={cn(
                "w-full rounded-2xl border bg-night-950/70 py-3.5 pl-4 pr-11 text-center text-lg font-black tracking-[0.6em] text-ember-300 outline-none transition-colors",
                err ? "border-red-500/60" : "border-white/10 focus:border-ember-500/60"
              )}
            />
          </div>
          {err && (
            <p className="mt-3 text-xs font-bold text-red-400">
              كلمة السر غير صحيحة، حاول مجدداً
            </p>
          )}
          <button
            type="submit"
            disabled={busy || pw.length === 0}
            className="btn-sheen mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 py-3.5 text-sm font-black text-night-950 transition-transform duration-200 hover:scale-[1.02] active:scale-95 disabled:opacity-50"
          >
            {busy && <Loader2 className="size-4 animate-spin" />}
            دخول
          </button>
          <a
            href="/"
            className="mt-5 inline-block text-[11px] font-bold text-zinc-600 underline-offset-4 transition-colors hover:text-ember-300 hover:underline"
          >
            العودة إلى المتجر
          </a>
        </form>
      </div>
    );
  }

  /* -------------------------------- Dashboard ------------------------------ */
  const newOrders = orders.filter((o) => o.status === "new").length;
  const totalValue = orders.reduce((s, o) => s + o.total, 0);
  const outOfStock = products.filter((p) => !p.inStock).length;

  const TABS: { id: Tab; label: string; Icon: typeof Package; badge?: number }[] = [
    { id: "products", label: "المنتجات", Icon: Package, badge: products.length },
    { id: "wholesale", label: "الجملة", Icon: Boxes, badge: wholesale.length },
    { id: "orders", label: "الطلبات", Icon: ClipboardList, badge: newOrders },
    { id: "settings", label: "الإعدادات", Icon: Settings2 },
  ];
  const title =
    tab === "products"
      ? "إدارة المنتجات"
      : tab === "wholesale"
        ? "عروض البيع بالجملة"
        : tab === "orders"
          ? "الطلبات الواردة"
          : "إعدادات المتجر";

  const stats = [
    { label: "إجمالي المنتجات", value: String(products.length), Icon: Package },
    { label: "عروض الجملة", value: String(wholesale.length), Icon: Boxes },
    { label: "طلبات جديدة", value: String(newOrders), Icon: ClipboardList },
    { label: "قيمة كل الطلبات", value: formatDZD(totalValue), Icon: Coins },
    { label: "نفد من المخزون", value: String(outOfStock), Icon: TriangleAlert },
  ];

  return (
    <div className="min-h-screen bg-night-950">
      <div className="mx-auto flex max-w-[1400px] flex-col gap-6 px-4 py-6 lg:flex-row">
        {/* Sidebar */}
        <aside className="shrink-0 lg:w-60">
          <div className="rounded-3xl border border-white/10 bg-night-900/70 p-5 backdrop-blur lg:sticky lg:top-6">
            <div className="flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-ember-400 to-ember-600 text-night-950 shadow-[0_0_30px_-4px_rgba(255,122,26,0.8)]">
                <Flame className="size-5" />
              </span>
              <div>
                <p className="text-sm font-black">Sarl Kahromania</p>
                <p className="text-[10px] font-bold tracking-[0.25em] text-ember-400/80">
                  لوحة التحكم
                </p>
              </div>
            </div>

            <nav className="mt-6 flex flex-wrap gap-2 lg:flex-col lg:flex-nowrap">
              {TABS.map(({ id, label, Icon, badge }) => (
                <button
                  key={id}
                  onClick={() => setTab(id)}
                  className={cn(
                    "relative flex flex-1 items-center gap-3 rounded-2xl px-4 py-3 text-xs font-black transition-all duration-300 lg:flex-none",
                    tab === id
                      ? "bg-gradient-to-l from-ember-500 to-ember-600 text-night-950 shadow-[0_12px_30px_-10px_rgba(255,122,26,0.7)]"
                      : "border border-white/5 bg-white/[0.02] text-zinc-400 hover:border-ember-500/30 hover:text-ember-300"
                  )}
                >
                  <Icon className="size-4" />
                  {label}
                  {badge !== undefined && badge > 0 && (
                    <span
                      className={cn(
                        "ms-auto rounded-full px-2 py-0.5 text-[10px] font-black",
                        tab === id
                          ? "bg-night-950/20 text-night-950"
                          : id === "orders"
                            ? "bg-ember-500/20 text-ember-300"
                            : "bg-white/5 text-zinc-500"
                      )}
                    >
                      {badge}
                    </span>
                  )}
                </button>
              ))}
            </nav>

            <div className="mt-5 space-y-2 border-t border-white/5 pt-4">
              <a
                href="/"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.02] px-4 py-3 text-xs font-black text-zinc-400 transition-colors hover:border-ember-500/30 hover:text-ember-300"
              >
                <ExternalLink className="size-4" />
                معاينة المتجر
              </a>
              <button
                onClick={logout}
                className="flex w-full items-center gap-3 rounded-2xl border border-white/5 bg-white/[0.02] px-4 py-3 text-xs font-black text-zinc-400 transition-colors hover:border-red-500/40 hover:text-red-400"
              >
                <LogOut className="size-4" />
                تسجيل الخروج
              </button>
            </div>
          </div>
        </aside>

        {/* Main */}
        <main className="min-w-0 flex-1">
          <div className="flex items-center justify-between gap-3 rounded-3xl border border-white/10 bg-night-900/70 px-6 py-4 backdrop-blur">
            <div>
              <h1 className="text-lg font-black">{title}</h1>
              <p className="mt-0.5 text-[11px] text-zinc-500">
                كل تعديل هنا ينعكس مباشرة على المتجر
              </p>
            </div>
            <button
              onClick={loadAll}
              className="flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2.5 text-[11px] font-black text-zinc-400 transition-colors hover:border-ember-500/40 hover:text-ember-300"
            >
              <RefreshCw className={cn("size-4", refreshing && "animate-spin")} />
              تحديث
            </button>
          </div>

          {/* Stats */}
          <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
            {stats.map(({ label, value, Icon }) => (
              <div
                key={label}
                className="rounded-2xl border border-white/10 bg-night-900/60 p-4"
              >
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-bold text-zinc-500">{label}</p>
                  <span className="grid size-8 place-items-center rounded-lg bg-ember-500/10 text-ember-400">
                    <Icon className="size-4" />
                  </span>
                </div>
                <p className="mt-2 text-xl font-black text-zinc-100">{value}</p>
              </div>
            ))}
          </div>

          <div className="mt-6">
            {loadingData ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div
                    key={i}
                    className="h-20 animate-pulse rounded-2xl border border-white/5 bg-night-900"
                  />
                ))}
              </div>
            ) : tab === "products" ? (
              <ProductsTab products={products} reload={loadAll} notify={notify} />
            ) : tab === "wholesale" ? (
              <WholesaleTab offers={wholesale} reload={loadAll} notify={notify} />
            ) : tab === "orders" ? (
              <OrdersTab orders={orders} reload={loadAll} notify={notify} />
            ) : (
              <SettingsTab settings={settings} notify={notify} />
            )}
          </div>
        </main>
      </div>
      <Toast toast={toast} />
    </div>
  );
}
