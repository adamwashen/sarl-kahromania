"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { Loader2, Pencil } from "lucide-react";
import { cn, formatDZD } from "@/lib/format";

export const adminInput =
  "w-full rounded-xl border border-white/10 bg-night-950/70 px-4 py-2.5 text-sm text-zinc-100 placeholder:text-zinc-600 outline-none transition-colors focus:border-ember-500/60";

export function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-extrabold text-zinc-300">
        {label}
      </span>
      {children}
      {hint && <span className="mt-1 block text-[10px] text-zinc-600">{hint}</span>}
    </label>
  );
}

export function InlinePrice({
  price,
  onSave,
}: {
  price: number;
  onSave: (v: number) => Promise<void>;
}) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(String(price));
  const [saving, setSaving] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) {
      setVal(String(price));
      setTimeout(() => inputRef.current?.select(), 40);
    }
  }, [editing, price]);

  async function commit() {
    const v = Math.round(Number(val) || 0);
    setEditing(false);
    if (v > 0 && v !== price && !saving) {
      setSaving(true);
      await onSave(v);
      setSaving(false);
    }
  }

  if (!editing) {
    return (
      <button
        onClick={() => setEditing(true)}
        title="اضغط لتعديل السعر"
        className="group ms-auto flex items-center justify-end gap-1.5"
      >
        <span className="text-sm font-black text-ember-400">{formatDZD(price)}</span>
        <span className="grid size-5 place-items-center rounded-md border border-white/10 text-zinc-600 transition-all group-hover:border-ember-500/50 group-hover:text-ember-300">
          <Pencil className="size-2.5" />
        </span>
      </button>
    );
  }

  return (
    <span className="ms-auto flex items-center gap-1.5">
      <input
        ref={inputRef}
        dir="ltr"
        type="number"
        min={0}
        value={val}
        disabled={saving}
        onChange={(e) => setVal(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") inputRef.current?.blur();
          if (e.key === "Escape") setEditing(false);
        }}
        className="w-24 rounded-lg border border-ember-500/60 bg-night-950 px-2 py-1.5 text-left text-sm font-black text-ember-300 outline-none shadow-[0_0_20px_-6px_rgba(255,122,26,0.6)]"
      />
      <span className="text-[10px] font-bold text-zinc-500">
        {saving ? <Loader2 className="size-3 animate-spin" /> : "دج"}
      </span>
    </span>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="group flex items-center gap-2"
    >
      <span
        className={cn(
          "relative h-6 w-11 rounded-full border transition-colors duration-300",
          checked
            ? "border-ember-500/60 bg-ember-500/25"
            : "border-white/15 bg-white/5"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 size-[18px] rounded-full transition-all duration-300",
            checked
              ? "left-[calc(100%-20px)] bg-ember-400 shadow-[0_0_12px_rgba(255,122,26,0.8)]"
              : "left-0.5 bg-zinc-500"
          )}
        />
      </span>
      {label && (
        <span
          className={cn(
            "text-[11px] font-bold transition-colors",
            checked ? "text-ember-300" : "text-zinc-500"
          )}
        >
          {label}
        </span>
      )}
    </button>
  );
}
