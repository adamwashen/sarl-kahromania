"use client";

import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ImagePlus,
  Loader2,
  Package,
  Pencil,
  Plus,
  Save,
  Search,
  Star,
  Trash2,
  X,
} from "lucide-react";
import type { Product } from "@/db/schema";
import { CATEGORIES } from "@/lib/defaults";
import { cn, formatDZD } from "@/lib/format";
import { Field, Toggle, adminInput, InlinePrice } from "./ui";

/* ------------------------------- Form modal ------------------------------- */

function ProductForm({
  initial,
  onClose,
  onSaved,
}: {
  initial: Product | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState(initial?.name ?? "");
  const [category, setCategory] = useState(initial?.category ?? "معلّقات");
  const [price, setPrice] = useState(String(initial?.price ?? ""));
  const [oldPrice, setOldPrice] = useState(
    initial?.oldPrice ? String(initial.oldPrice) : ""
  );
  const [badge, setBadge] = useState(initial?.badge ?? "");
  const [description, setDescription] = useState(initial?.description ?? "");
  const [image, setImage] = useState(initial?.image ?? "");
  const [featured, setFeatured] = useState(initial?.featured ?? false);
  const [inStock, setInStock] = useState(initial?.inStock ?? true);
  const [sort, setSort] = useState(String(initial?.sort ?? 0));
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  async function upload(file: File) {
    setUploading(true);
    setError("");
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const d = await res.json();
      if (d.url) setImage(d.url);
      else setError(d.error || "تعذّر رفع الصورة");
    } catch {
      setError("تعذّر رفع الصورة");
    } finally {
      setUploading(false);
    }
  }

  async function save() {
    setError("");
    if (name.trim().length < 2) return setError("أدخل اسم المنتج.");
    if ((Number(price) || 0) <= 0) return setError("أدخل سعراً صحيحاً.");
    setSaving(true);
    const payload = {
      name: name.trim(),
      category: category.trim() || "عام",
      price: Number(price) || 0,
      oldPrice: oldPrice.trim() === "" ? null : Number(oldPrice),
      badge: badge.trim() || null,
      description: description.trim(),
      image,
      featured,
      inStock,
      sort: Number(sort) || 0,
    };
    try {
      const res = await fetch(
        initial ? `/api/products/${initial.id}` : "/api/products",
        {
          method: initial ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) throw new Error();
      onSaved();
    } catch {
      setError("تعذّر الحفظ، حاول مجدداً.");
      setSaving(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-[70] grid place-items-center overflow-y-auto bg-night-950/85 p-4 backdrop-blur-md"
    >
      <motion.div
        initial={{ opacity: 0, y: 36, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.97 }}
        transition={{ type: "spring", stiffness: 260, damping: 26 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-3xl overflow-hidden rounded-3xl border border-white/10 bg-night-900 shadow-2xl"
      >
        <div className="flex items-center justify-between border-b border-white/5 px-6 py-4">
          <h3 className="text-base font-black">
            {initial ? "تعديل المنتج" : "إضافة منتج جديد"}
          </h3>
          <button
            onClick={onClose}
            className="grid size-9 place-items-center rounded-full border border-white/10 text-zinc-400 transition-colors hover:text-ember-400"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="grid gap-6 p-6 md:grid-cols-[230px_1fr]">
          {/* Image column */}
          <div>
            <div className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-white/10 bg-night-950">
              {image ? (
                <img src={image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full place-items-center text-zinc-700">
                  <ImagePlus className="size-10" />
                </div>
              )}
              {uploading && (
                <div className="absolute inset-0 grid place-items-center bg-night-950/70">
                  <Loader2 className="size-8 animate-spin text-ember-400" />
                </div>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) upload(f);
                e.target.value = "";
              }}
            />
            <button
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-ember-500/30 bg-ember-500/10 py-2.5 text-xs font-black text-ember-300 transition-colors hover:bg-ember-500/20"
            >
              <ImagePlus className="size-4" />
              رفع صورة من الجهاز
            </button>
            <p className="mt-2 text-center text-[10px] text-zinc-600">
              أو ألصق رابط صورة مباشرة:
            </p>
            <input
              dir="ltr"
              value={image}
              onChange={(e) => setImage(e.target.value)}
              placeholder="https://…"
              className={`${adminInput} mt-1.5 text-left text-xs`}
            />
          </div>

          {/* Fields column */}
          <div className="space-y-4">
            <Field label="اسم المنتج">
              <input
                className={adminInput}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: ثريا حلزونية ذهبية"
              />
            </Field>

            <div className="grid grid-cols-2 gap-4">
              <Field label="الفئة">
                <input
                  className={adminInput}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  list="admin-cats"
                />
                <datalist id="admin-cats">
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </Field>
              <Field label="شارة (اختياري)" hint="مثل: جديد، عرض خاص، الأكثر مبيعاً">
                <input
                  className={adminInput}
                  value={badge}
                  onChange={(e) => setBadge(e.target.value)}
                />
              </Field>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <Field label="السعر (دج)">
                <input
                  type="number"
                  dir="ltr"
                  className={`${adminInput} text-left`}
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="0"
                />
              </Field>
              <Field label="السعر قبل الخصم" hint="اتركه فارغاً إن وُجد خصم">
                <input
                  type="number"
                  dir="ltr"
                  className={`${adminInput} text-left`}
                  value={oldPrice}
                  onChange={(e) => setOldPrice(e.target.value)}
                  placeholder="—"
                />
              </Field>
              <Field label="الترتيب" hint="الأصغر يظهر أولاً">
                <input
                  type="number"
                  dir="ltr"
                  className={`${adminInput} text-left`}
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                />
              </Field>
            </div>

            <Field label="الوصف">
              <textarea
                rows={3}
                className={`${adminInput} resize-none`}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="وصف قصير وجذاب للمنتج…"
              />
            </Field>

            <div className="flex flex-wrap items-center gap-6 rounded-2xl border border-white/5 bg-white/[0.02] px-4 py-3">
              <Toggle checked={featured} onChange={setFeatured} label="منتج مميز" />
              <Toggle checked={inStock} onChange={setInStock} label="متوفر في المخزون" />
            </div>

            {error && (
              <p className="rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-[11px] font-bold text-red-300">
                {error}
              </p>
            )}

            <button
              onClick={save}
              disabled={saving || uploading}
              className="btn-sheen flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 py-3.5 text-sm font-black text-night-950 transition-transform duration-200 hover:scale-[1.01] active:scale-95 disabled:opacity-60"
            >
              {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
              {initial ? "حفظ التعديلات" : "إضافة المنتج"}
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* --------------------------------- Tab ----------------------------------- */

export default function ProductsTab({
  products,
  reload,
  notify,
}: {
  products: Product[];
  reload: () => Promise<void>;
  notify: (msg: string) => void;
}) {
  const [search, setSearch] = useState("");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [confirmDel, setConfirmDel] = useState<number | null>(null);
  const [busy, setBusy] = useState<number | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim();
    if (!q) return products;
    return products.filter(
      (p) => p.name.includes(q) || p.category.includes(q)
    );
  }, [products, search]);

  async function patch(id: number, data: Record<string, unknown>) {
    setBusy(id);
    try {
      await fetch(`/api/products/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      await reload();
    } finally {
      setBusy(null);
    }
  }

  async function remove(id: number) {
    setBusy(id);
    try {
      await fetch(`/api/products/${id}`, { method: "DELETE" });
      setConfirmDel(null);
      await reload();
      notify("تم حذف المنتج");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      {/* Toolbar */}
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="relative min-w-52 flex-1">
          <Search className="absolute right-4 top-1/2 size-4 -translate-y-1/2 text-zinc-600" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن منتج…"
            className={`${adminInput} pr-11`}
          />
        </div>
        <button
          onClick={() => {
            setEditing(null);
            setFormOpen(true);
          }}
          className="btn-sheen flex items-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-6 py-3 text-xs font-black text-night-950 shadow-[0_12px_32px_-10px_rgba(255,122,26,0.7)] transition-transform duration-200 hover:scale-[1.03] active:scale-95"
        >
          <Plus className="size-4" />
          إضافة منتج
        </button>
      </div>
      <p className="mb-5 flex items-center gap-2 rounded-2xl border border-ember-500/20 bg-ember-500/5 px-4 py-2.5 text-[11px] font-bold text-ember-300/90">
        <Pencil className="size-3.5" />
        تلميح: اضغط على سعر أي منتج لتعديله مباشرة — وأزرار النجمة والمفتاح للتمييز والتوفر، وسلة المهملات للحذف.
      </p>

      {/* List */}
      <div className="space-y-3">
        {filtered.map((p) => (
          <motion.div
            key={p.id}
            layout
            className={cn(
              "flex flex-wrap items-center gap-4 rounded-2xl border border-white/10 bg-night-900/60 p-4 transition-colors",
              busy === p.id && "opacity-60"
            )}
          >
            <div className="relative size-16 shrink-0 overflow-hidden rounded-xl border border-white/10 bg-night-950">
              {p.image ? (
                <img src={p.image} alt="" className="h-full w-full object-cover" />
              ) : (
                <div className="grid h-full place-items-center text-zinc-700">
                  <Package className="size-5" />
                </div>
              )}
            </div>

            <div className="min-w-40 flex-1">
              <p className="truncate text-sm font-extrabold">{p.name}</p>
              <div className="mt-1.5 flex flex-wrap items-center gap-2">
                <span className="rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-0.5 text-[10px] font-bold text-zinc-400">
                  {p.category}
                </span>
                {p.badge && (
                  <span className="rounded-full bg-ember-500/15 px-2.5 py-0.5 text-[10px] font-black text-ember-300">
                    {p.badge}
                  </span>
                )}
              </div>
            </div>

            <div className="min-w-32 text-end">
              <InlinePrice
                price={p.price}
                onSave={async (v) => {
                  await patch(p.id, { price: v });
                  notify("تم تحديث السعر بنجاح");
                }}
              />
              {p.oldPrice ? (
                <p className="mt-1 text-[11px] text-zinc-600 line-through">
                  {formatDZD(p.oldPrice)}
                </p>
              ) : (
                <p className="mt-1 text-[11px] text-zinc-700">بدون خصم</p>
              )}
            </div>

            <div className="flex items-center gap-3">
              <Toggle
                checked={p.inStock}
                onChange={(v) => patch(p.id, { inStock: v })}
                label="متوفر"
              />
              <button
                onClick={() => patch(p.id, { featured: !p.featured })}
                title={p.featured ? "إزالة من المميزة" : "تمييز المنتج"}
                className={cn(
                  "grid size-9 place-items-center rounded-xl border transition-all",
                  p.featured
                    ? "border-ember-500/50 bg-ember-500/15 text-ember-400 shadow-[0_0_16px_-4px_rgba(255,122,26,0.7)]"
                    : "border-white/10 text-zinc-600 hover:text-ember-300"
                )}
              >
                <Star className={cn("size-4", p.featured && "fill-current")} />
              </button>
              <button
                onClick={() => {
                  setEditing(p);
                  setFormOpen(true);
                }}
                className="grid size-9 place-items-center rounded-xl border border-white/10 text-zinc-400 transition-colors hover:border-ember-500/40 hover:text-ember-300"
              >
                <Pencil className="size-4" />
              </button>
              {confirmDel === p.id ? (
                <button
                  onClick={() => remove(p.id)}
                  className="rounded-xl border border-red-500/50 bg-red-500/15 px-3 py-2 text-[11px] font-black text-red-300"
                >
                  تأكيد الحذف؟
                </button>
              ) : (
                <button
                  onClick={() => {
                    setConfirmDel(p.id);
                    setTimeout(
                      () => setConfirmDel((c) => (c === p.id ? null : c)),
                      3000
                    );
                  }}
                  className="grid size-9 place-items-center rounded-xl border border-white/10 text-zinc-500 transition-colors hover:border-red-500/40 hover:text-red-400"
                >
                  <Trash2 className="size-4" />
                </button>
              )}
            </div>
          </motion.div>
        ))}
        {filtered.length === 0 && (
          <div className="rounded-3xl border border-dashed border-white/10 bg-night-900/40 py-16 text-center">
            <Package className="mx-auto size-10 text-zinc-700" />
            <p className="mt-3 text-sm font-bold text-zinc-500">لا توجد منتجات مطابقة</p>
          </div>
        )}
      </div>

      <AnimatePresence>
        {formOpen && (
          <ProductForm
            initial={editing}
            onClose={() => setFormOpen(false)}
            onSaved={async () => {
              setFormOpen(false);
              await reload();
              notify(editing ? "تم تحديث المنتج" : "تمت إضافة المنتج");
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
