"use client";

import { motion } from "framer-motion";
import {
  ArrowDown,
  Lightbulb,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Truck,
} from "lucide-react";
import { formatDZD } from "@/lib/format";

export type SettingsMap = Record<string, string>;

const ease = [0.22, 1, 0.36, 1] as const;

export default function Hero({
  settings,
  waLink,
  featured,
}: {
  settings: SettingsMap;
  waLink: string;
  featured: { name: string; price: number; image: string } | null;
}) {
  return (
    <section className="relative overflow-hidden">
      {/* Ambient background */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full bg-ember-600/20 blur-[140px]" />
        <div className="absolute bottom-0 right-[-120px] h-[380px] w-[380px] rounded-full bg-ember-500/10 blur-[120px]" />
        <div
          className="absolute inset-0 opacity-[0.13]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.28) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.28) 1px, transparent 1px)",
            backgroundSize: "72px 72px",
            maskImage:
              "radial-gradient(ellipse 75% 60% at 50% 0%, black, transparent)",
          }}
        />
      </div>

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-4 pb-20 pt-12 sm:px-6 lg:grid-cols-[1.02fr_0.98fr] lg:gap-10 lg:pt-16">
        {/* Copy */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease }}
            className="inline-flex items-center gap-2 rounded-full border border-ember-500/30 bg-ember-500/10 px-4 py-2 text-xs font-bold text-ember-300 sm:text-sm"
          >
            <Sparkles className="size-4" />
            {settings.heroKicker}
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 32 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.08, ease }}
            className="mt-6 text-[2.6rem] font-black leading-[1.25] sm:text-6xl sm:leading-[1.2] xl:text-[4.4rem]"
          >
            {settings.heroTitle}{" "}
            <span className="glow-text bg-gradient-to-l from-ember-200 via-ember-400 to-ember-600 bg-clip-text text-transparent">
              {settings.heroAccent}
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 28 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.16, ease }}
            className="mt-6 max-w-xl text-sm leading-8 text-zinc-400 sm:text-base sm:leading-9"
          >
            {settings.heroSubtitle}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.24, ease }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#products"
              className="btn-sheen group inline-flex items-center gap-2.5 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-7 py-4 text-sm font-black text-night-950 shadow-[0_18px_44px_-12px_rgba(255,122,26,0.65)] transition-transform duration-300 hover:scale-[1.03] active:scale-95 sm:text-base"
            >
              <Lightbulb className="size-5" />
              تصفّح التشكيلة
              <ArrowDown className="size-4 transition-transform duration-300 group-hover:translate-y-0.5" />
            </a>
            <a
              href={waLink}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2.5 rounded-2xl border border-white/15 bg-white/[0.03] px-7 py-4 text-sm font-bold text-zinc-100 backdrop-blur transition-all duration-300 hover:border-emerald-400/50 hover:bg-emerald-500/10 hover:text-emerald-300 sm:text-base"
            >
              <MessageCircle className="size-5" />
              اطلب عبر واتساب
            </a>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.32, ease }}
            className="mt-12 grid max-w-xl grid-cols-3 divide-x divide-white/10 divide-x-reverse rounded-3xl border border-white/10 bg-night-900/70 backdrop-blur"
          >
            {[
              { v: "+58", l: "ولاية توصيل", Icon: Truck },
              { v: "+2400", l: "زبون سعيد", Icon: Sparkles },
              { v: "100%", l: "جودة مضمونة", Icon: ShieldCheck },
            ].map(({ v, l, Icon }) => (
              <div key={l} className="flex flex-col items-center gap-1 px-2 py-5">
                <Icon className="mb-1 size-4 text-ember-400" />
                <span className="text-xl font-black text-ember-300 sm:text-2xl">
                  {v}
                </span>
                <span className="text-[11px] text-zinc-500 sm:text-xs">{l}</span>
              </div>
            ))}
          </motion.div>
        </div>

        {/* Visual */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.15, ease }}
          className="relative mx-auto w-full max-w-[520px]"
        >
          <div className="animate-ember-pulse absolute -inset-6 rounded-[3rem] bg-ember-500/20 blur-[70px]" />
          <div className="relative overflow-hidden rounded-[3rem] border border-white/10 shadow-[0_40px_90px_-30px_rgba(0,0,0,0.9)]">
            <img
              src="/images/hero.jpg"
              alt="إضاءة كاهرومانيا"
              className="aspect-[4/5] w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-night-950/80 via-transparent to-night-950/20" />
          </div>

          {/* Floating chips */}
          <div className="animate-floaty absolute -right-4 top-10 hidden items-center gap-2.5 rounded-2xl border border-white/10 bg-night-900/90 px-4 py-3 shadow-xl backdrop-blur sm:flex">
            <span className="grid size-9 place-items-center rounded-xl bg-ember-500/15 text-ember-400">
              <Truck className="size-4" />
            </span>
            <div>
              <p className="text-xs font-extrabold">توصيل سريع</p>
              <p className="text-[10px] text-zinc-500">لجميع الولايات</p>
            </div>
          </div>

          <div className="animate-floaty-late absolute -left-4 bottom-28 hidden items-center gap-2.5 rounded-2xl border border-white/10 bg-night-900/90 px-4 py-3 shadow-xl backdrop-blur sm:flex">
            <span className="grid size-9 place-items-center rounded-xl bg-emerald-500/15 text-emerald-400">
              <MessageCircle className="size-4" />
            </span>
            <div>
              <p className="text-xs font-extrabold">اطلب في دقيقة</p>
              <p className="text-[10px] text-zinc-500">عبر واتساب فقط</p>
            </div>
          </div>

          {featured && (
            <motion.a
              href="#products"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.8, ease }}
              className="absolute bottom-5 right-5 left-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-night-950/85 p-3 backdrop-blur-md transition-colors hover:border-ember-500/50 sm:right-6 sm:left-auto sm:w-72"
            >
              <img
                src={featured.image}
                alt={featured.name}
                className="size-14 rounded-xl border border-white/10 object-cover"
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold text-zinc-200">
                  {featured.name}
                </p>
                <p className="mt-1 text-sm font-black text-ember-400">
                  {formatDZD(featured.price)}
                </p>
              </div>
              <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-ember-500/15 text-ember-400">
                <Lightbulb className="size-4" />
              </span>
            </motion.a>
          )}
        </motion.div>
      </div>
    </section>
  );
}
