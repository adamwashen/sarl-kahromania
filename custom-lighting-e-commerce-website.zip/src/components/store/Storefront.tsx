"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Flame, MessageCircle, ShoppingBag, Truck } from "lucide-react";
import type { Product, WholesaleOffer } from "@/db/schema";
import { DEFAULT_SETTINGS } from "@/lib/defaults";
import { buildWhatsAppLink, formatDZD } from "@/lib/format";
import Hero, { type SettingsMap } from "./Hero";
import ProductsSection from "./Products";
import WholesaleSection from "./Wholesale";
import { About, HowTo, Marquee, SiteFooter } from "./Sections";
import CartDrawer from "./CartDrawer";
import SecretLogin from "./SecretLogin";
import { Toast, type ToastState } from "./ui";

export type CartLine = {
  id: number;
  name: string;
  price: number;
  image: string;
  qty: number;
};

export default function Storefront() {
  const [settings, setSettings] = useState<SettingsMap>(DEFAULT_SETTINGS);
  const [products, setProducts] = useState<Product[]>([]);
  const [wholesale, setWholesale] = useState<WholesaleOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [toast, setToast] = useState<ToastState>(null);
  const [loginOpen, setLoginOpen] = useState(false);

  const clicks = useRef<number[]>([]);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showToast = (text: string) => {
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), text });
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  };

  useEffect(() => {
    fetch("/api/settings", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        if (d?.settings) setSettings({ ...DEFAULT_SETTINGS, ...d.settings });
      })
      .catch(() => {});
    fetch("/api/products", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setProducts(d.products ?? []))
      .catch(() => setProducts([]))
      .finally(() => setLoading(false));
    fetch("/api/wholesale", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setWholesale(d.offers ?? []))
      .catch(() => setWholesale([]));
    try {
      const raw = localStorage.getItem("kr_cart");
      if (raw) setCart(JSON.parse(raw));
    } catch {}
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("kr_cart", JSON.stringify(cart));
    } catch {}
  }, [cart]);

  /* ------------------------------- cart logic ------------------------------ */
  const addToCart = (p: Product, qty = 1) => {
    setCart((c) => {
      const ex = c.find((l) => l.id === p.id);
      if (ex)
        return c.map((l) =>
          l.id === p.id ? { ...l, qty: Math.min(99, l.qty + qty) } : l
        );
      return [
        ...c,
        { id: p.id, name: p.name, price: p.price, image: p.image, qty },
      ];
    });
    showToast("تمت الإضافة إلى السلة");
  };
  const updateQty = (id: number, delta: number) =>
    setCart((c) =>
      c
        .map((l) => (l.id === id ? { ...l, qty: l.qty + delta } : l))
        .filter((l) => l.qty > 0)
    );
  const removeLine = (id: number) => setCart((c) => c.filter((l) => l.id !== id));
  const clearCart = () => setCart([]);

  const subtotal = cart.reduce((s, l) => s + l.price * l.qty, 0);
  const count = cart.reduce((s, l) => s + l.qty, 0);

  /* ------------------------------ whatsapp --------------------------------- */
  const waLink = useMemo(
    () =>
      buildWhatsAppLink(
        settings.whatsapp,
        "مرحباً Sarl Kahromania، أريد الاستفسار عن منتجاتكم."
      ),
    [settings.whatsapp]
  );
  const orderOne = (p: Product, qty = 1) => {
    const msg = [
      "طلب منتج — Sarl Kahromania",
      "——————————————",
      `المنتج: ${p.name}`,
      `الكمية: ${qty}`,
      `السعر: ${formatDZD(p.price * qty)}`,
      "——————————————",
      "أرغب في الطلب، شكراً.",
    ].join("\n");
    window.open(buildWhatsAppLink(settings.whatsapp, msg), "_blank");
  };

  /* ------------------------- secret admin trigger -------------------------- */
  // 5 rapid clicks at the top of the page open the password gate.
  const secretTap = () => {
    const now = Date.now();
    clicks.current = clicks.current.filter((t) => now - t < 2000);
    clicks.current.push(now);
    if (clicks.current.length >= 5) {
      clicks.current = [];
      setLoginOpen(true);
    }
  };

  const featured = products.find((p) => p.featured) ?? products[0] ?? null;
  const categories = useMemo(
    () => [...new Set(products.map((p) => p.category).filter(Boolean))],
    [products]
  );

  return (
    <div id="top" className="relative min-h-screen">
      {/* ============================== Header ============================== */}
      <header onClick={secretTap} className="sticky top-0 z-50 cursor-default select-none">
        <div className="border-b border-ember-500/15 bg-gradient-to-l from-ember-600/15 via-ember-500/5 to-ember-600/15">
          <p className="mx-auto flex max-w-7xl items-center justify-center gap-2 px-4 py-2 text-center text-[11px] font-bold text-ember-300/90 sm:text-xs">
            <Truck className="size-3.5 shrink-0" />
            {settings.announcement}
          </p>
        </div>
        <div className="border-b border-white/5 bg-night-950/80 backdrop-blur-xl">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
            <a href="#top" className="flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-ember-400 to-ember-600 text-night-950 shadow-[0_0_30px_-4px_rgba(255,122,26,0.8)]">
                <Flame className="size-5" />
              </span>
              <span>
                <span className="block text-sm font-black leading-5">
                  Sarl Kahromania
                </span>
                <span className="block text-[10px] font-bold tracking-[0.3em] text-zinc-500">
                  GROUPE AL-RYADA
                </span>
              </span>
            </a>

            <nav className="hidden items-center gap-7 text-[13px] font-bold text-zinc-400 md:flex">
              {[
                ["الرئيسية", "#top"],
                ["المنتجات", "#products"],
                ["الجملة", "#wholesale"],
                ["كيف تطلب؟", "#how"],
                ["من نحن", "#about"],
              ].map(([label, href]) => (
                <a
                  key={href}
                  href={href}
                  className="relative transition-colors duration-300 hover:text-ember-300 after:absolute after:-bottom-1.5 after:right-0 after:h-px after:w-0 after:bg-ember-400 after:transition-all after:duration-300 hover:after:w-full"
                >
                  {label}
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-2.5">
              <a
                href={waLink}
                target="_blank"
                rel="noreferrer"
                className="hidden items-center gap-2 rounded-xl border border-emerald-500/25 bg-emerald-500/10 px-4 py-2.5 text-xs font-extrabold text-emerald-300 transition-all duration-300 hover:bg-emerald-500/20 sm:flex"
              >
                <MessageCircle className="size-4" />
                واتساب المتجر
              </a>
              <button
                onClick={() => setCartOpen(true)}
                className="relative grid size-11 place-items-center rounded-xl border border-white/10 bg-white/[0.03] text-zinc-200 transition-all duration-300 hover:border-ember-500/50 hover:text-ember-300 active:scale-95"
              >
                <ShoppingBag className="size-5" />
                {count > 0 && (
                  <span className="absolute -left-1.5 -top-1.5 grid min-w-5 place-items-center rounded-full bg-gradient-to-l from-ember-400 to-ember-600 px-1 py-0.5 text-[10px] font-black text-night-950 shadow-[0_0_16px_rgba(255,122,26,0.8)]">
                    {count}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* ============================== Content ============================= */}
      <main className="grain relative">
        <Hero
          settings={settings}
          waLink={waLink}
          featured={
            featured
              ? { name: featured.name, price: featured.price, image: featured.image }
              : null
          }
        />

        <Marquee text={settings.marquee} />

        {loading ? (
          <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6">
            <div className="mx-auto h-10 w-64 animate-pulse rounded-full bg-night-800" />
            <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="animate-pulse overflow-hidden rounded-3xl border border-white/5 bg-night-900"
                >
                  <div className="aspect-[4/5] bg-night-800" />
                  <div className="space-y-3 p-5">
                    <div className="h-3 w-1/3 rounded bg-night-700" />
                    <div className="h-4 w-4/5 rounded bg-night-700" />
                    <div className="h-9 rounded-xl bg-night-800" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <ProductsSection
            products={products}
            deliveryText={settings.deliveryText}
            onAdd={addToCart}
            onWhatsApp={orderOne}
          />
        )}

        <WholesaleSection
          offers={wholesale}
          settings={settings}
          whatsapp={settings.whatsapp}
        />

        <HowTo waLink={waLink} />
        <About settings={settings} />
      </main>

      <SiteFooter settings={settings} categories={categories} waLink={waLink} />

      {/* ============================ Overlays ============================== */}
      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        subtotal={subtotal}
        onQty={updateQty}
        onRemove={removeLine}
        onClear={clearCart}
        whatsapp={settings.whatsapp}
        onBrowse={() => {
          setCartOpen(false);
          document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
        }}
      />
      <SecretLogin open={loginOpen} onClose={() => setLoginOpen(false)} />
      <Toast toast={toast} />
    </div>
  );
}
