"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Eye,
  MessageCircle,
  Minus,
  Plus,
  ShoppingBag,
  Truck,
  X,
} from "lucide-react";
import type { Product } from "@/db/schema";
import { cn, formatDZD } from "@/lib/format";
import { SectionHeading } from "./ui";

const ease = [0.22, 1, 0.36, 1] as const;

function discount(p: Product): number | null {
  if (p.oldPrice && p.oldPrice > p.price) {
    return Math.round(((p.oldPrice - p.price) / p.oldPrice) * 100);
  }
  return null;
}

/* --------------------------------- Card ---------------------------------- */

function ProductCard({
  product,
  onAdd,
  onQuick,
  onWhatsApp,
}: {
  product: Product;
  onAdd: (p: Product) => void;
  onQuick: (p: Product) => void;
  onWhatsApp: (p: Product) => void;
}) {
  const d = discount(product);
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 26 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.55, ease }}
      className="group relative overflow-hidden rounded-3xl border border-white/10 bg-night-900/70 transition-all duration-500 hover:border-ember-500/50 hover:shadow-[0_24px_70px_-24px_rgba(255,122,26,0.35)]"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-night-950">
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.08]"
          />
        ) : (
          <div className="grid h-full w-full place-items-center text-zinc-700">
            <ShoppingBag className="size-10" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-night-950/85 via-transparent to-night-950/10" />
        <div className="absolute right-3 top-3 flex flex-col items-end gap-2">
          {product.badge && (
            <span className="rounded-full bg-gradient-to-l from-ember-500 to-ember-600 px-3 py-1 text-[10px] font-black text-night-950 shadow-[0_8px_24px_-6px_rgba(255,122,26,0.8)]">
              {product.badge}
            </span>
          )}
          {d && (
            <span className="rounded-full border border-ember-400/40 bg-night-950/80 px-2.5 py-1 text-[10px] font-black text-ember-300 backdrop-blur">
              خصم {d}%
            </span>
          )}
        </div>
        {!product.inStock && (
          <div className="absolute inset-0 grid place-items-center bg-night-950/70 backdrop-blur-[2px]">
            <span className="rounded-full border border-white/15 bg-night-900 px-4 py-1.5 text-xs font-bold text-zinc-300">
              نفدت الكمية مؤقتاً
            </span>
          </div>
        )}
      </div>

      <div className="p-5">
        <p className="text-[11px] font-bold text-ember-400/90">{product.category}</p>
        <h3 className="mt-1.5 line-clamp-1 text-[15px] font-extrabold leading-7">
          {product.name}
        </h3>
        <p className="mt-1 line-clamp-2 min-h-[2.6rem] text-xs leading-5 text-zinc-500">
          {product.description}
        </p>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-lg font-black text-ember-400">
            {formatDZD(product.price)}
          </span>
          {product.oldPrice && product.oldPrice > product.price && (
            <span className="text-xs text-zinc-600 line-through">
              {formatDZD(product.oldPrice)}
            </span>
          )}
        </div>
        <div className="mt-4 flex gap-2">
          <button
            onClick={() => onAdd(product)}
            disabled={!product.inStock}
            className={cn(
              "flex flex-1 items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-xs font-extrabold transition-all duration-300 active:scale-95",
              product.inStock
                ? "bg-ember-500/15 text-ember-300 hover:bg-ember-500 hover:text-night-950 hover:shadow-[0_10px_30px_-8px_rgba(255,122,26,0.8)]"
                : "cursor-not-allowed bg-white/5 text-zinc-600"
            )}
          >
            <ShoppingBag className="size-4" />
            أضف للسلة
          </button>
          <button
            onClick={() => onWhatsApp(product)}
            title="اطلب مباشرة عبر واتساب"
            className="grid size-10 place-items-center rounded-xl border border-emerald-500/25 text-emerald-400 transition-all duration-300 hover:bg-emerald-500/10 active:scale-95"
          >
            <MessageCircle className="size-4" />
          </button>
          <button
            onClick={() => onQuick(product)}
            title="عرض سريع"
            className="grid size-10 place-items-center rounded-xl border border-white/10 text-zinc-400 transition-all duration-300 hover:border-ember-500/40 hover:text-ember-300 active:scale-95"
          >
            <Eye className="size-4" />
          </button>
        </div>
      </div>
    </motion.article>
  );
}

/* ------------------------------- Quick view ------------------------------- */

function QuickView({
  product,
  deliveryText,
  onClose,
  onAdd,
  onWhatsApp,
}: {
  product: Product;
  deliveryText: string;
  onClose: () => void;
  onAdd: (p: Product, qty: number) => void;
  onWhatsApp: (p: Product, qty: number) => void;
}) {
  const [qty, setQty] = useState(1);
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[70] grid place-items-center overflow-y-auto bg-night-950/80 p-4 backdrop-blur-md"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 24, scale: 0.97 }}
        transition={{ type: "spring", stiffness: 260, damping: 26 }}
        onClick={(e) => e.stopPropagation()}
        className="relative grid w-full max-w-3xl overflow-hidden rounded-3xl border border-white/10 bg-night-900 shadow-2xl md:grid-cols-2"
      >
        <button
          onClick={onClose}
          className="absolute left-4 top-4 z-10 grid size-9 place-items-center rounded-full border border-white/10 bg-night-950/70 text-zinc-400 backdrop-blur transition-colors hover:text-ember-400"
        >
          <X className="size-4" />
        </button>
        <div className="relative aspect-square bg-night-950">
          {product.image && (
            <img
              src={product.image}
              alt={product.name}
              className="h-full w-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-l from-night-900/40 to-transparent" />
        </div>
        <div className="flex flex-col p-7">
          <p className="text-xs font-bold text-ember-400">{product.category}</p>
          <h3 className="mt-2 text-2xl font-black leading-9">{product.name}</h3>
          <p className="mt-3 text-sm leading-7 text-zinc-400">{product.description}</p>
          <div className="mt-5 flex items-baseline gap-3">
            <span className="text-3xl font-black text-ember-400">
              {formatDZD(product.price)}
            </span>
            {product.oldPrice && product.oldPrice > product.price && (
              <span className="text-sm text-zinc-600 line-through">
                {formatDZD(product.oldPrice)}
              </span>
            )}
          </div>

          <div className="mt-6 flex items-center gap-4">
            <span className="text-xs font-bold text-zinc-500">الكمية</span>
            <div className="flex items-center gap-1 rounded-xl border border-white/10 p-1">
              <button
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="grid size-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/5 hover:text-ember-400"
              >
                <Minus className="size-4" />
              </button>
              <span className="w-8 text-center text-sm font-black">{qty}</span>
              <button
                onClick={() => setQty((q) => Math.min(99, q + 1))}
                className="grid size-8 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/5 hover:text-ember-400"
              >
                <Plus className="size-4" />
              </button>
            </div>
          </div>

          <div className="mt-6 grid gap-2.5">
            <button
              onClick={() => {
                onAdd(product, qty);
                onClose();
              }}
              disabled={!product.inStock}
              className="btn-sheen flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-5 py-3.5 text-sm font-black text-night-950 transition-transform duration-300 hover:scale-[1.02] active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <ShoppingBag className="size-4" />
              أضف للسلة — {formatDZD(product.price * qty)}
            </button>
            <button
              onClick={() => onWhatsApp(product, qty)}
              className="flex items-center justify-center gap-2 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 px-5 py-3.5 text-sm font-extrabold text-emerald-300 transition-all duration-300 hover:bg-emerald-500/20 active:scale-95"
            >
              <MessageCircle className="size-4" />
              اطلب مباشرة عبر واتساب
            </button>
          </div>

          <p className="mt-5 flex items-start gap-2 rounded-xl border border-white/5 bg-white/[0.03] p-3 text-[11px] leading-5 text-zinc-500">
            <Truck className="mt-0.5 size-4 shrink-0 text-ember-400" />
            {deliveryText}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* -------------------------------- Section --------------------------------- */

export default function ProductsSection({
  products,
  deliveryText,
  onAdd,
  onWhatsApp,
}: {
  products: Product[];
  deliveryText: string;
  onAdd: (p: Product, qty?: number) => void;
  onWhatsApp: (p: Product, qty?: number) => void;
}) {
  const [cat, setCat] = useState("الكل");
  const [quick, setQuick] = useState<Product | null>(null);

  const cats = useMemo(() => {
    const set = new Set(products.map((p) => p.category).filter(Boolean));
    return ["الكل", ...set];
  }, [products]);

  const filtered = useMemo(
    () => (cat === "الكل" ? products : products.filter((p) => p.category === cat)),
    [cat, products]
  );

  return (
    <section id="products" className="relative mx-auto max-w-7xl scroll-mt-28 px-4 py-24 sm:px-6 lg:py-32">
      <div className="pointer-events-none absolute right-0 top-40 h-80 w-80 rounded-full bg-ember-600/10 blur-[120px]" />
      <SectionHeading
        kicker="تشكيلة Sarl Kahromania"
        title="قطع تُضيء المكان… وتحيي الديكور"
        sub="كل قطعة في التشكيلة مختارة لتكون نقطة الضوء التي يدور حولها جمال المساحة."
      />

      {/* Filters */}
      <div className="hide-scrollbar mt-10 flex justify-start gap-2 overflow-x-auto pb-2 sm:justify-center">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={cn(
              "relative shrink-0 rounded-full px-5 py-2.5 text-xs font-extrabold transition-colors duration-300",
              cat === c ? "text-night-950" : "text-zinc-400 hover:text-ember-300"
            )}
          >
            {cat === c && (
              <motion.span
                layoutId="cat-pill"
                transition={{ type: "spring", stiffness: 380, damping: 32 }}
                className="absolute inset-0 rounded-full bg-gradient-to-l from-ember-400 to-ember-600 shadow-[0_10px_30px_-10px_rgba(255,122,26,0.9)]"
              />
            )}
            <span className="relative z-10">{c}</span>
            {cat !== c && (
              <span className="absolute inset-0 rounded-full border border-white/10 bg-white/[0.02]" />
            )}
          </button>
        ))}
      </div>

      <motion.div layout className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <AnimatePresence mode="popLayout">
          {filtered.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onAdd={(prod) => onAdd(prod, 1)}
              onQuick={setQuick}
              onWhatsApp={(prod) => onWhatsApp(prod, 1)}
            />
          ))}
        </AnimatePresence>
      </motion.div>

      {filtered.length === 0 && (
        <p className="py-20 text-center text-sm text-zinc-500">
          لا توجد منتجات في هذه الفئة حالياً.
        </p>
      )}

      <AnimatePresence>
        {quick && (
          <QuickView
            product={quick}
            deliveryText={deliveryText}
            onClose={() => setQuick(null)}
            onAdd={onAdd}
            onWhatsApp={onWhatsApp}
          />
        )}
      </AnimatePresence>
    </section>
  );
}
