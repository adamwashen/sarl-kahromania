"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Loader2, Lock, ShieldCheck, X } from "lucide-react";
import { useRouter } from "next/navigation";

export default function SecretLogin({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const router = useRouter();
  const [pw, setPw] = useState("");
  const [err, setErr] = useState(false);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setPw("");
      setErr(false);
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [open]);

  async function submit() {
    if (loading) return;
    setLoading(true);
    setErr(false);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: pw }),
      });
      if (res.ok) {
        onClose();
        router.push("/admin");
      } else {
        setErr(true);
        setPw("");
      }
    } catch {
      setErr(true);
    } finally {
      setLoading(false);
    }
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-[90] grid place-items-center bg-night-950/85 p-4 backdrop-blur-lg"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 26 }}
            animate={
              err
                ? { opacity: 1, scale: 1, y: 0, x: [0, -10, 10, -8, 8, 0] }
                : { opacity: 1, scale: 1, y: 0 }
            }
            exit={{ opacity: 0, scale: 0.95, y: 14 }}
            transition={{ type: "spring", stiffness: 280, damping: 24 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-sm overflow-hidden rounded-3xl border border-ember-500/25 bg-night-900 p-8 text-center shadow-[0_40px_120px_-30px_rgba(255,122,26,0.35)]"
          >
            <div className="pointer-events-none absolute -top-24 left-1/2 h-48 w-64 -translate-x-1/2 rounded-full bg-ember-500/20 blur-[70px]" />
            <button
              onClick={onClose}
              className="absolute left-4 top-4 grid size-8 place-items-center rounded-full text-zinc-500 transition-colors hover:text-ember-400"
            >
              <X className="size-4" />
            </button>
            <div className="relative mx-auto grid size-16 place-items-center rounded-2xl bg-gradient-to-br from-ember-500/25 to-ember-600/5 text-ember-400 shadow-[inset_0_0_30px_rgba(255,122,26,0.2)]">
              <ShieldCheck className="size-8" />
            </div>
            <h3 className="relative mt-5 text-xl font-black">منطقة الإدارة</h3>
            <p className="relative mt-1.5 text-xs leading-6 text-zinc-500">
              أدخل كلمة السر للوصول إلى لوحة تحكم المتجر
            </p>
            <form
              className="relative mt-6"
              onSubmit={(e) => {
                e.preventDefault();
                submit();
              }}
            >
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 size-4 -translate-y-1/2 text-zinc-600" />
                <input
                  ref={inputRef}
                  type="password"
                  inputMode="numeric"
                  dir="ltr"
                  value={pw}
                  onChange={(e) => {
                    setPw(e.target.value);
                    setErr(false);
                  }}
                  placeholder="••••"
                  className={`w-full rounded-2xl border bg-night-950/70 py-3.5 pl-4 pr-11 text-center text-lg font-black tracking-[0.6em] text-ember-300 outline-none transition-colors placeholder:tracking-[0.6em] ${
                    err ? "border-red-500/60" : "border-white/10 focus:border-ember-500/60"
                  }`}
                />
              </div>
              {err && (
                <p className="mt-3 text-xs font-bold text-red-400">
                  كلمة السر غير صحيحة، حاول مجدداً
                </p>
              )}
              <button
                type="submit"
                disabled={loading || pw.length === 0}
                className="btn-sheen mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 py-3.5 text-sm font-black text-night-950 transition-transform duration-200 hover:scale-[1.02] active:scale-95 disabled:opacity-50"
              >
                {loading ? <Loader2 className="size-4 animate-spin" /> : null}
                دخول اللوحة
              </button>
            </form>
            <p className="relative mt-4 text-[10px] tracking-[0.25em] text-zinc-700">
              SARL KAHROMANIA — GROUPE AL-RYADA
            </p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
