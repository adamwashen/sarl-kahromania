"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  CheckCircle2,
  Loader2,
  MessageCircle,
  Minus,
  Plus,
  ShoppingCart,
  Trash2,
  Truck,
  X,
} from "lucide-react";
import { buildWhatsAppLink, cn, formatDZD } from "@/lib/format";
import { WILAYAS } from "@/lib/wilayas";
import type { CartLine } from "./Storefront";

const ease = [0.22, 1, 0.36, 1] as const;

export default function CartDrawer({
  open,
  onClose,
  cart,
  subtotal,
  onQty,
  onRemove,
  onClear,
  whatsapp,
  onBrowse,
}: {
  open: boolean;
  onClose: () => void;
  cart: CartLine[];
  subtotal: number;
  onQty: (id: number, delta: number) => void;
  onRemove: (id: number) => void;
  onClear: () => void;
  whatsapp: string;
  onBrowse: () => void;
}) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [wilaya, setWilaya] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState<{ id: number; msg: string } | null>(null);

  function buildMessage(orderId: number) {
    const lines = [
      "طلب جديد — Sarl Kahromania (Groupe Al-Ryada)",
      "——————————————",
      `الاسم: ${name}`,
      `الهاتف: ${phone}`,
      `الولاية: ${wilaya}`,
      address ? `العنوان: ${address}` : null,
      notes ? `ملاحظات: ${notes}` : null,
      "——————————————",
      "المنتجات:",
      ...cart.map(
        (l, i) => `${i + 1}. ${l.name} × ${l.qty} — ${formatDZD(l.price * l.qty)}`
      ),
      "——————————————",
      `المجموع الإجمالي: ${formatDZD(subtotal)}`,
      `رقم الطلب: #${orderId}`,
    ].filter(Boolean);
    return lines.join("\n");
  }

  async function checkout() {
    setError("");
    if (cart.length === 0) return;
    if (name.trim().length < 2) return setError("يرجى إدخال الاسم الكامل.");
    if (phone.replace(/[^\d]/g, "").length < 9)
      return setError("يرجى إدخال رقم هاتف صحيح.");
    if (!wilaya) return setError("يرجى اختيار الولاية.");
    setLoading(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: name.trim(),
          phone: phone.trim(),
          wilaya,
          address: address.trim(),
          notes: notes.trim(),
          items: cart,
          total: subtotal,
        }),
      });
      if (!res.ok) throw new Error();
      const data = await res.json();
      const msg = buildMessage(data.order?.id ?? 0);
      window.open(buildWhatsAppLink(whatsapp, msg), "_blank");
      setDone({ id: data.order?.id ?? 0, msg });
      onClear();
    } catch {
      setError("حدث خطأ أثناء تسجيل الطلب، حاول مجدداً.");
    } finally {
      setLoading(false);
    }
  }

  function reset() {
    setDone(null);
    setError("");
  }

  const inputCls =
    "w-full rounded-xl border border-white/10 bg-night-950/60 px-4 py-3 text-sm text-zinc-100 placeholder:text-zinc-600 outline-none transition-colors focus:border-ember-500/60 focus:bg-night-950";

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-[60] bg-night-950/70 backdrop-blur-sm"
          />
          <motion.aside
            initial={{ x: "-105%" }}
            animate={{ x: 0 }}
            exit={{ x: "-105%" }}
            transition={{ type: "spring", stiffness: 300, damping: 34 }}
            className="fixed inset-y-0 left-0 z-[65] flex w-full max-w-md flex-col border-e border-white/10 bg-night-900 shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/5 px-6 py-5">
              <div className="flex items-center gap-3">
                <span className="grid size-10 place-items-center rounded-xl bg-ember-500/15 text-ember-400">
                  <ShoppingCart className="size-5" />
                </span>
                <div>
                  <h3 className="text-base font-black">سلة التسوق</h3>
                  <p className="text-[11px] text-zinc-500">
                    {cart.length > 0 ? `${cart.length} منتجات` : "سلتك تنتظر الإضاءة"}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="grid size-9 place-items-center rounded-full border border-white/10 text-zinc-400 transition-colors hover:border-ember-500/40 hover:text-ember-400"
              >
                <X className="size-4" />
              </button>
            </div>

            {done ? (
              /* ---------------- Success state ---------------- */
              <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
                <motion.div
                  initial={{ scale: 0.6, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", stiffness: 240, damping: 16 }}
                >
                  <CheckCircle2 className="size-20 text-ember-400 drop-shadow-[0_0_25px_rgba(255,122,26,0.6)]" />
                </motion.div>
                <h4 className="text-xl font-black">تم تسجيل طلبك بنجاح</h4>
                <p className="text-sm font-bold text-ember-300">رقم الطلب: #{done.id}</p>
                <p className="max-w-xs text-xs leading-6 text-zinc-500">
                  الخطوة الأخيرة: أرسل الرسالة في واتساب ليتم تأكيد طلبك فوراً —
                  الدفع والتوصيل يُتفق عليهما في المحادثة.
                </p>
                <a
                  href={buildWhatsAppLink(whatsapp, done.msg)}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-sheen mt-2 flex items-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-6 py-3.5 text-sm font-black text-night-950"
                >
                  <MessageCircle className="size-4" />
                  فتح واتساب مجدداً
                </a>
                <button
                  onClick={() => {
                    reset();
                    onBrowse();
                  }}
                  className="text-xs font-bold text-zinc-400 underline-offset-4 hover:text-ember-300 hover:underline"
                >
                  متابعة التسوق
                </button>
              </div>
            ) : cart.length === 0 ? (
              /* ---------------- Empty state ---------------- */
              <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
                <ShoppingCart className="size-16 text-zinc-700" />
                <p className="text-base font-extrabold text-zinc-300">سلّتك فارغة</p>
                <p className="text-xs leading-6 text-zinc-500">
                  أضف بعض الأضواء لتنير يومك — التشكيلة بانتظارك.
                </p>
                <button
                  onClick={onBrowse}
                  className="rounded-2xl bg-ember-500/15 px-6 py-3 text-xs font-black text-ember-300 transition-all hover:bg-ember-500 hover:text-night-950"
                >
                  تصفّح المنتجات
                </button>
              </div>
            ) : (
              /* ---------------- Cart content ---------------- */
              <>
                <div className="hide-scrollbar flex-1 overflow-y-auto px-6 py-5">
                  <div className="space-y-3">
                    <AnimatePresence initial={false}>
                      {cart.map((l) => (
                        <motion.div
                          key={l.id}
                          layout
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 30, height: 0, marginBottom: 0 }}
                          transition={{ duration: 0.3, ease }}
                          className="flex gap-3 overflow-hidden rounded-2xl border border-white/10 bg-night-950/50 p-3"
                        >
                          {l.image && (
                            <img
                              src={l.image}
                              alt={l.name}
                              className="size-16 shrink-0 rounded-xl border border-white/10 object-cover"
                            />
                          )}
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-xs font-extrabold">{l.name}</p>
                            <p className="mt-1 text-xs font-black text-ember-400">
                              {formatDZD(l.price)}
                            </p>
                            <div className="mt-2 flex items-center justify-between">
                              <div className="flex items-center gap-1 rounded-lg border border-white/10 p-0.5">
                                <button
                                  onClick={() => onQty(l.id, -1)}
                                  className="grid size-6 place-items-center rounded-md text-zinc-400 hover:bg-white/5 hover:text-ember-400"
                                >
                                  <Minus className="size-3" />
                                </button>
                                <span className="w-6 text-center text-xs font-black">
                                  {l.qty}
                                </span>
                                <button
                                  onClick={() => onQty(l.id, 1)}
                                  className="grid size-6 place-items-center rounded-md text-zinc-400 hover:bg-white/5 hover:text-ember-400"
                                >
                                  <Plus className="size-3" />
                                </button>
                              </div>
                              <button
                                onClick={() => onRemove(l.id)}
                                className="grid size-7 place-items-center rounded-lg text-zinc-600 transition-colors hover:bg-red-500/10 hover:text-red-400"
                              >
                                <Trash2 className="size-3.5" />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </AnimatePresence>
                  </div>

                  {/* Customer form */}
                  <div className="mt-6 space-y-3">
                    <p className="text-xs font-black text-zinc-300">معلومات التوصيل</p>
                    <input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="الاسم الكامل"
                      className={inputCls}
                    />
                    <input
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="رقم الهاتف (مثال: 0550 12 34 56)"
                      inputMode="tel"
                      dir="ltr"
                      className={cn(inputCls, "text-left")}
                    />
                    <select
                      value={wilaya}
                      onChange={(e) => setWilaya(e.target.value)}
                      className={cn(inputCls, !wilaya && "text-zinc-600")}
                    >
                      <option value="" disabled>
                        اختر الولاية
                      </option>
                      {WILAYAS.map((w) => (
                        <option key={w} value={w} className="text-zinc-100">
                          {w}
                        </option>
                      ))}
                    </select>
                    <input
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="البلدية / العنوان (اختياري)"
                      className={inputCls}
                    />
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="ملاحظات إضافية (اختياري)"
                      rows={2}
                      className={cn(inputCls, "resize-none")}
                    />
                  </div>
                </div>

                {/* Footer */}
                <div className="border-t border-white/5 bg-night-950/60 px-6 py-5">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-bold text-zinc-400">المجموع</span>
                    <span className="text-xl font-black text-ember-400">
                      {formatDZD(subtotal)}
                    </span>
                  </div>
                  <p className="mt-2 flex items-center gap-2 text-[11px] text-zinc-600">
                    <Truck className="size-3.5 text-ember-500" />
                    التوصيل لكل الولايات — التكلفة تُحدد في محادثة واتساب.
                  </p>
                  {error && (
                    <p className="mt-3 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-2.5 text-[11px] font-bold text-red-300">
                      {error}
                    </p>
                  )}
                  <button
                    onClick={checkout}
                    disabled={loading}
                    className="btn-sheen mt-4 flex w-full items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-6 py-4 text-sm font-black text-night-950 shadow-[0_16px_40px_-12px_rgba(255,122,26,0.7)] transition-transform duration-300 hover:scale-[1.02] active:scale-95 disabled:opacity-60"
                  >
                    {loading ? (
                      <Loader2 className="size-5 animate-spin" />
                    ) : (
                      <MessageCircle className="size-5" />
                    )}
                    {loading ? "جارٍ تسجيل الطلب..." : "تأكيد الطلب عبر واتساب"}
                  </button>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
