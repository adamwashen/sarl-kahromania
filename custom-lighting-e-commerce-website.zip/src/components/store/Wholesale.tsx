"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  BadgePercent,
  Boxes,
  FileCheck2,
  Handshake,
  MessageCircle,
  Minus,
  Plus,
  Zap,
} from "lucide-react";
import type { WholesaleOffer } from "@/db/schema";
import { buildWhatsAppLink, formatDZD } from "@/lib/format";
import { SectionHeading } from "./ui";
import type { SettingsMap } from "./Hero";

const ease = [0.22, 1, 0.36, 1] as const;

function OfferCard({
  offer,
  whatsapp,
  index,
}: {
  offer: WholesaleOffer;
  whatsapp: string;
  index: number;
}) {
  const [qty, setQty] = useState(offer.minQty);
  const total = qty * offer.unitPrice;

  function order() {
    const msg = [
      "طلب جملة — Sarl Kahromania (Groupe Al-Ryada)",
      "——————————————",
      `العرض: ${offer.name}`,
      `الكمية: ${qty}`,
      `سعر الوحدة: ${formatDZD(offer.unitPrice)}`,
      `الإجمالي التقديري: ${formatDZD(total)}`,
      "——————————————",
      "أرغب في عرض سعر نهائي وتفاصيل التوصيل، شكراً.",
    ].join("\n");
    window.open(buildWhatsAppLink(whatsapp, msg), "_blank");
  }

  return (
    <motion.article
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.65, delay: index * 0.08, ease }}
      className="group relative flex flex-col overflow-hidden rounded-3xl border border-white/10 bg-night-950/80 transition-all duration-500 hover:border-ember-500/50 hover:shadow-[0_24px_70px_-24px_rgba(255,122,26,0.35)]"
    >
      <div className="relative h-44 overflow-hidden">
        {offer.image && (
          <img
            src={offer.image}
            alt={offer.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.07]"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-night-950 via-night-950/30 to-transparent" />
        <span className="absolute right-3 top-3 flex items-center gap-1.5 rounded-full bg-gradient-to-l from-ember-500 to-ember-600 px-3 py-1 text-[10px] font-black text-night-950 shadow-[0_8px_24px_-6px_rgba(255,122,26,0.8)]">
          <Boxes className="size-3" />
          جملة
        </span>
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className="line-clamp-1 text-[15px] font-extrabold leading-7">
          {offer.name}
        </h3>
        <p className="mt-1.5 line-clamp-3 min-h-[3.6rem] text-xs leading-6 text-zinc-500">
          {offer.description}
        </p>

        <div className="mt-4 flex items-center justify-between rounded-2xl border border-white/5 bg-white/[0.03] px-4 py-3">
          <div>
            <p className="text-[10px] font-bold text-zinc-500">سعر الوحدة</p>
            <p className="text-lg font-black text-ember-400">
              {formatDZD(offer.unitPrice)}
            </p>
          </div>
          <span className="rounded-full border border-ember-500/30 bg-ember-500/10 px-3 py-1.5 text-[10px] font-black text-ember-300">
            الحد الأدنى: {offer.minQty}
          </span>
        </div>

        {/* Quantity calculator */}
        <div className="mt-4">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-zinc-400">الكمية</span>
            <div className="flex items-center gap-1 rounded-xl border border-white/10 p-1">
              <button
                onClick={() => setQty((q) => Math.max(offer.minQty, q - 1))}
                className="grid size-7 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/5 hover:text-ember-400"
              >
                <Minus className="size-3.5" />
              </button>
              <span className="w-10 text-center text-sm font-black">{qty}</span>
              <button
                onClick={() => setQty((q) => Math.min(9999, q + (q < 20 ? 1 : 5)))}
                className="grid size-7 place-items-center rounded-lg text-zinc-400 transition-colors hover:bg-white/5 hover:text-ember-400"
              >
                <Plus className="size-3.5" />
              </button>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between rounded-xl border border-ember-500/25 bg-ember-500/[0.07] px-4 py-2.5">
            <span className="text-[11px] font-bold text-zinc-400">الإجمالي</span>
            <span className="text-base font-black text-ember-300">
              {formatDZD(total)}
            </span>
          </div>
        </div>

        <button
          onClick={order}
          className="btn-sheen mt-4 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-4 py-3 text-xs font-black text-night-950 transition-transform duration-300 hover:scale-[1.02] active:scale-95"
        >
          <MessageCircle className="size-4" />
          اطلب هذه الكمية عبر واتساب
        </button>
      </div>
    </motion.article>
  );
}

export default function WholesaleSection({
  offers,
  settings,
  whatsapp,
}: {
  offers: WholesaleOffer[];
  settings: SettingsMap;
  whatsapp: string;
}) {
  const active = offers.filter((o) => o.active);
  const perks = [
    {
      Icon: BadgePercent,
      t: "أسعار متدرجة",
      d: "كلما زادت الكمية انخفض سعر الوحدة — اطلب عرضك الخاص.",
    },
    {
      Icon: FileCheck2,
      t: "توثيق رسمي",
      d: "فاتورة رسمية باسم SARL للشركات والمحلات التجارية.",
    },
    {
      Icon: Zap,
      t: "أولوية التجهيز",
      d: "طلبات الجملة تُجهَّز وتُشحن قبل غيرها مع تتبع مباشر.",
    },
    {
      Icon: Handshake,
      t: "شراكة دائمة",
      d: "مرافقة كاملة لمشاريع الفنادق والمقاهي ومكاتب الديكور.",
    },
  ];

  const catalogMsg = buildWhatsAppLink(
    whatsapp,
    "السلام عليكم، أنا تاجر/مهني وأرغب في الاطلاع على كتالوج الجملة وأسعار الكميات لدى Sarl Kahromania."
  );

  return (
    <section
      id="wholesale"
      className="relative scroll-mt-28 border-y border-white/5 bg-night-900/40 py-24 lg:py-32"
    >
      <div className="pointer-events-none absolute left-1/2 top-0 h-64 w-[640px] -translate-x-1/2 rounded-full bg-ember-600/10 blur-[120px]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          kicker={settings.wholesaleKicker}
          title={settings.wholesaleTitle}
          sub={settings.wholesaleSubtitle}
        />

        {active.length > 0 ? (
          <div className="mt-14 grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {active.map((o, i) => (
              <OfferCard key={o.id} offer={o} whatsapp={whatsapp} index={i} />
            ))}
          </div>
        ) : (
          <p className="py-16 text-center text-sm text-zinc-500">
            عروض الجملة تُحدَّث حالياً — تواصل معنا عبر واتساب لأي استفسار.
          </p>
        )}

        {/* Perks */}
        <div className="mt-14 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {perks.map(({ Icon, t, d }, i) => (
            <motion.div
              key={t}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.07, ease }}
              className="rounded-2xl border border-white/10 bg-night-950/60 p-5 transition-colors duration-300 hover:border-ember-500/40"
            >
              <span className="grid size-11 place-items-center rounded-xl bg-gradient-to-br from-ember-500/25 to-ember-600/10 text-ember-400">
                <Icon className="size-5" />
              </span>
              <p className="mt-3.5 text-sm font-extrabold">{t}</p>
              <p className="mt-1 text-[11px] leading-5 text-zinc-500">{d}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease }}
          className="mt-12 flex flex-col items-center justify-center gap-3 text-center"
        >
          <a
            href={catalogMsg}
            target="_blank"
            rel="noreferrer"
            className="btn-sheen inline-flex items-center gap-2.5 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-8 py-4 text-sm font-black text-night-950 shadow-[0_18px_44px_-12px_rgba(255,122,26,0.65)] transition-transform duration-300 hover:scale-[1.03] sm:text-base"
          >
            <Boxes className="size-5" />
            اطلب كتالوج الجملة الكامل
          </a>
          <p className="text-[11px] text-zinc-600">
            للكميات الخاصة أو تصاميم النيون المخصصة، راسلنا مباشرة عبر واتساب.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
