"use client";

import { motion } from "framer-motion";
import {
  Flame,
  Mail,
  MapPin,
  MessageCircle,
  Phone,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  Truck,
} from "lucide-react";
import { SectionHeading } from "./ui";
import type { SettingsMap } from "./Hero";

const ease = [0.22, 1, 0.36, 1] as const;

function InstagramIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

function FacebookIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
      <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
    </svg>
  );
}

/* ---------------------------------- Marquee --------------------------------- */

export function Marquee({ text }: { text: string }) {
  const items = text.split("•").map((s) => s.trim()).filter(Boolean);
  const row = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-y border-white/5 bg-night-900/70 py-4">
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-night-950 to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-night-950 to-transparent" />
      <div dir="ltr" className="animate-marquee flex w-max items-center gap-10">
        {row.map((item, i) => (
          <span
            key={i}
            dir="rtl"
            className="flex items-center gap-3 whitespace-nowrap text-sm font-bold text-zinc-400"
          >
            <Flame className="size-4 text-ember-500" />
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ----------------------------------- About ---------------------------------- */

export function About({ settings }: { settings: SettingsMap }) {
  const perks = [
    { Icon: Sparkles, t: "تصاميم حصرية", d: "قطع منتقاة لا تجدها في المتاجر التقليدية." },
    { Icon: ShieldCheck, t: "جودة مضمونة", d: "فحص كامل قبل الشحن وضمان على كل منتج." },
    { Icon: Truck, t: "توصيل 58 ولاية", d: "شركاء توصيل موثوقون حتى باب منزلك." },
    { Icon: MessageCircle, t: "مرافقة كاملة", d: "نصائح اختيار وتركيب عبر واتساب." },
  ];
  return (
    <section id="about" className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:py-32">
      <div className="pointer-events-none absolute left-0 top-24 h-72 w-72 rounded-full bg-ember-600/10 blur-[110px]" />
      <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.9, ease }}
          className="relative order-2 lg:order-1"
        >
          <div className="absolute -inset-5 rounded-[2.5rem] bg-ember-500/15 blur-[60px]" />
          <div className="relative overflow-hidden rounded-[2.5rem] border border-white/10">
            <img
              src="/images/about.jpg"
              alt="معرض كاهرومانيا"
              className="aspect-[4/3] w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-night-950/70 to-transparent" />
            <div className="absolute bottom-5 right-5 rounded-2xl border border-white/10 bg-night-950/80 px-5 py-3 backdrop-blur">
              <p className="text-[10px] font-bold tracking-[0.25em] text-zinc-400">
                GROUPE AL-RYADA
              </p>
              <p className="text-sm font-black text-ember-400">Sarl Kahromania — الجزائر</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.9, ease }}
          className="order-1 lg:order-2"
        >
          <span className="inline-flex items-center gap-2 rounded-full border border-ember-500/30 bg-ember-500/10 px-4 py-1.5 text-xs font-bold text-ember-300">
            <span className="size-1.5 rounded-full bg-ember-400 shadow-[0_0_10px_2px_rgba(255,154,61,0.9)]" />
            من نحن
          </span>
          <h2 className="mt-5 text-3xl font-black leading-[1.4] sm:text-4xl sm:leading-[1.35]">
            {settings.aboutTitle}
          </h2>
          <p className="mt-5 text-sm leading-8 text-zinc-400 sm:text-base sm:leading-9">
            {settings.aboutText}
          </p>
          <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {perks.map(({ Icon, t, d }, i) => (
              <motion.div
                key={t}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.08, ease }}
                className="group rounded-2xl border border-white/10 bg-night-900/60 p-4 transition-colors duration-300 hover:border-ember-500/40 hover:bg-ember-500/5"
              >
                <span className="grid size-10 place-items-center rounded-xl bg-ember-500/15 text-ember-400 transition-transform duration-300 group-hover:scale-110">
                  <Icon className="size-5" />
                </span>
                <p className="mt-3 text-sm font-extrabold">{t}</p>
                <p className="mt-1 text-xs leading-6 text-zinc-500">{d}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ----------------------------------- HowTo ---------------------------------- */

export function HowTo({ waLink }: { waLink: string }) {
  const steps = [
    {
      n: "01",
      Icon: ShoppingBag,
      t: "املأ سلّتك",
      d: "تصفّح التشكيلة وأضف القطع التي أشعلت إعجابك إلى السلة.",
    },
    {
      n: "02",
      Icon: MessageCircle,
      t: "أرسل الطلب عبر واتساب",
      d: "بضغطة واحدة يصلنا طلبك كاملاً مع عنوانك — لا تسجيل، لا بطاقة بنكية.",
    },
    {
      n: "03",
      Icon: Truck,
      t: "استلم عند بابك",
      d: "نؤكد معك فوراً ونشحن طلبك حتى باب المنزل في أي ولاية.",
    },
  ];
  return (
    <section id="how" className="relative border-y border-white/5 bg-night-900/40 py-24 lg:py-28">
      <div className="pointer-events-none absolute right-1/2 top-0 h-64 w-[600px] translate-x-1/2 rounded-full bg-ember-600/10 blur-[110px]" />
      <div className="mx-auto max-w-7xl px-4 sm:px-6">
        <SectionHeading
          kicker="الدفع عبر واتساب فقط"
          title="اطلب في ثلاث خطوات"
          sub="لا حسابات، لا بطاقات، لا تعقيد — كل شيء يتم في محادثة واتساب واحدة."
        />
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          {steps.map(({ n, Icon, t, d }, i) => (
            <motion.div
              key={n}
              initial={{ opacity: 0, y: 34 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: i * 0.12, ease }}
              className="group relative overflow-hidden rounded-3xl border border-white/10 bg-night-950/70 p-7 transition-colors duration-300 hover:border-ember-500/40"
            >
              <span className="pointer-events-none absolute -left-3 -top-7 text-[6.5rem] font-black text-white/[0.04] transition-colors duration-300 group-hover:text-ember-500/10">
                {n}
              </span>
              <span className="relative grid size-14 place-items-center rounded-2xl bg-gradient-to-br from-ember-500/25 to-ember-600/10 text-ember-400 shadow-[inset_0_0_20px_rgba(255,122,26,0.15)] transition-transform duration-300 group-hover:scale-110">
                <Icon className="size-6" />
              </span>
              <h3 className="relative mt-6 text-xl font-extrabold">{t}</h3>
              <p className="relative mt-2.5 text-sm leading-7 text-zinc-500">{d}</p>
            </motion.div>
          ))}
        </div>
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2, ease }}
          className="mt-12 flex justify-center"
        >
          <a
            href={waLink}
            target="_blank"
            rel="noreferrer"
            className="btn-sheen inline-flex items-center gap-2.5 rounded-2xl bg-gradient-to-l from-ember-500 to-ember-600 px-8 py-4 text-sm font-black text-night-950 shadow-[0_18px_44px_-12px_rgba(255,122,26,0.65)] transition-transform duration-300 hover:scale-[1.03] sm:text-base"
          >
            <MessageCircle className="size-5" />
            تحدّث معنا الآن
          </a>
        </motion.div>
      </div>
    </section>
  );
}

/* ---------------------------------- Footer ---------------------------------- */

export function SiteFooter({
  settings,
  categories,
  waLink,
}: {
  settings: SettingsMap;
  categories: string[];
  waLink: string;
}) {
  return (
    <footer className="relative border-t border-white/5 bg-night-900/50">
      <div className="pointer-events-none absolute bottom-0 left-1/2 h-40 w-[700px] -translate-x-1/2 rounded-full bg-ember-600/10 blur-[100px]" />
      <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <div className="flex items-center gap-3">
              <span className="grid size-11 place-items-center rounded-2xl bg-gradient-to-br from-ember-400 to-ember-600 text-night-950 shadow-[0_0_30px_-4px_rgba(255,122,26,0.8)]">
                <Flame className="size-5" />
              </span>
              <div>
                <p className="text-sm font-black">Sarl Kahromania</p>
                <p className="text-[10px] font-bold tracking-[0.3em] text-zinc-500">
                  GROUPE AL-RYADA
                </p>
              </div>
            </div>
            <p className="mt-5 max-w-xs text-xs leading-6 text-zinc-500">
              إضاءة ديكور فاخرة من فرع مجموعة الريادة في الجزائر. الطلب والدفع
              حصرياً عبر واتساب مع توصيل لكل الولايات.
            </p>
            <div className="mt-5 flex gap-2.5">
              {[
                { Icon: InstagramIcon, href: settings.instagram },
                { Icon: FacebookIcon, href: settings.facebook },
                { Icon: MessageCircle, href: waLink },
              ].map(({ Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  target="_blank"
                  rel="noreferrer"
                  className="grid size-10 place-items-center rounded-xl border border-white/10 text-zinc-400 transition-all duration-300 hover:border-ember-500/50 hover:bg-ember-500/10 hover:text-ember-400"
                >
                  <Icon className="size-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <p className="text-sm font-extrabold text-zinc-200">روابط سريعة</p>
            <ul className="mt-4 space-y-2.5 text-xs text-zinc-500">
              {[
                ["الرئيسية", "#top"],
                ["المنتجات", "#products"],
                ["قسم الجملة", "#wholesale"],
                ["كيف تطلب؟", "#how"],
                ["من نحن", "#about"],
              ].map(([l, h]) => (
                <li key={h}>
                  <a href={h} className="transition-colors hover:text-ember-400">
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-sm font-extrabold text-zinc-200">الفئات</p>
            <ul className="mt-4 space-y-2.5 text-xs text-zinc-500">
              {categories.slice(0, 5).map((c) => (
                <li key={c}>
                  <a href="#products" className="transition-colors hover:text-ember-400">
                    {c}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-sm font-extrabold text-zinc-200">تواصل معنا</p>
            <ul className="mt-4 space-y-3 text-xs text-zinc-500">
              <li className="flex items-center gap-2.5">
                <MapPin className="size-4 shrink-0 text-ember-500" />
                {settings.address}
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="size-4 shrink-0 text-ember-500" />
                <span dir="ltr">{settings.phoneDisplay}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="size-4 shrink-0 text-ember-500" />
                {settings.email}
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-3 border-t border-white/5 pt-6 text-[11px] text-zinc-600 sm:flex-row">
          <p>{settings.footerText}</p>
          <p className="flex items-center gap-1.5">
            صُنع بشغف في الجزائر
            <Flame className="size-3.5 text-ember-500" />
          </p>
        </div>
      </div>
    </footer>
  );
}
