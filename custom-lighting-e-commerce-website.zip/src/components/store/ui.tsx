"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Flame } from "lucide-react";

export type ToastState = { id: number; text: string } | null;

export function Toast({ toast }: { toast: ToastState }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-6 z-[80] flex justify-center px-4">
      <AnimatePresence>
        {toast && (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 24, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.97 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
            className="flex items-center gap-2.5 rounded-2xl border border-ember-500/40 bg-night-800/95 px-5 py-3 text-sm font-semibold text-ember-200 shadow-[0_0_40px_-8px_rgba(255,122,26,0.55)] backdrop-blur"
          >
            <Flame className="size-4 text-ember-400" />
            {toast.text}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export function SectionHeading({
  kicker,
  title,
  sub,
}: {
  kicker: string;
  title: string;
  sub?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 28 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="mx-auto max-w-2xl text-center"
    >
      <span className="inline-flex items-center gap-2 rounded-full border border-ember-500/30 bg-ember-500/10 px-4 py-1.5 text-xs font-bold text-ember-300">
        <span className="size-1.5 rounded-full bg-ember-400 shadow-[0_0_10px_2px_rgba(255,154,61,0.9)]" />
        {kicker}
      </span>
      <h2 className="mt-5 text-3xl font-black leading-[1.3] sm:text-4xl lg:text-5xl">
        {title}
      </h2>
      {sub && (
        <p className="mt-4 text-sm leading-7 text-zinc-400 sm:text-base sm:leading-8">
          {sub}
        </p>
      )}
    </motion.div>
  );
}
